'use server';

import { resend } from '@/lib/email/resend';
import { QuoteAutoReplyTemplate } from '@/components/email/QuoteAutoReplyTemplate';
import { QuoteNotificationTemplate } from '@/components/email/QuoteNotificationTemplate';

export interface QuoteFormData {
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  country: string;
  city: string;
  industry: string;
  productDescription: string;
  quantity: string;
  deliveryTimeline: string;
  additionalRequirements: string;
  scheduledDate?: string;
  scheduledTime?: string;
  requestType?: string;
}

export interface EmailResponse {
  success: boolean;
  error?: string;
  messageId?: string;
  sandboxMode?: boolean;
}

export async function sendQuoteEmails(data: QuoteFormData): Promise<EmailResponse> {
  const {
    companyName,
    contactPerson,
    email,
    phone,
    country,
    city,
    industry,
    productDescription,
    quantity,
    deliveryTimeline,
    additionalRequirements,
    scheduledDate,
    scheduledTime,
    requestType
  } = data;

  try {
    // Validate required fields
    if (!companyName || !contactPerson || !email || !phone || !country || !city || !productDescription) {
      return {
        success: false,
        error: 'All required fields must be filled',
      };
    }

    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return {
        success: false,
        error: 'Invalid email address',
      };
    }

    // Get the sending domain from environment or use default
    const fromDomain = process.env.RESEND_DOMAIN || 'resend.dev';
    const fromEmail = `noreply@${fromDomain}`;
    const businessEmail = process.env.BUSINESS_EMAIL || 'belal.elansary@r-aletqan.com';

    console.log('Attempting to send emails...', {
      fromEmail,
      customerEmail: email,
      businessEmail,
      isSandboxMode: fromDomain === 'resend.dev'
    });

    // Detect sandbox mode (using resend.dev domain)
    const isSandboxMode = fromDomain === 'resend.dev';

    if (isSandboxMode) {
      // In sandbox mode, we can only send to the verified email
      // Send a combined notification to business email that includes customer info
      console.log('⚠️ Running in SANDBOX MODE - sending all emails to business email only');
      
      const sandboxResult = await resend.emails.send({
        from: fromEmail,
        to: businessEmail,
        replyTo: email,
        subject: `[SANDBOX] New Quote Request from ${companyName} - ${contactPerson}`,
        react: QuoteNotificationTemplate({
          companyName,
          contactPerson,
          email,
          phone,
          country,
          city,
          industry,
          productDescription,
          quantity,
          deliveryTimeline,
          additionalRequirements,
          scheduledDate,
          scheduledTime,
          requestType,
        }),
      });

      if (sandboxResult.error) {
        console.error('Sandbox email error:', sandboxResult.error);
        return {
          success: false,
          error: 'Failed to send notification email. Please contact us directly.',
        };
      }

      console.log('✅ Sandbox email sent successfully to:', businessEmail);
      
      return {
        success: true,
        messageId: sandboxResult.data?.id,
        sandboxMode: true,
      };
    }

    // Production mode - send both emails
    // Send auto-reply to user
    const autoReplyResult = await resend.emails.send({
      from: fromEmail,
      to: email,
      subject: 'Thank You for Your Quote Request - Riyadh Aletqan',
      react: QuoteAutoReplyTemplate({
        name: contactPerson,
        companyName,
        email,
      }),
    });

    if (autoReplyResult.error) {
      console.error('Auto-reply error:', autoReplyResult.error);
      return {
        success: false,
        error: 'Failed to send confirmation email. Please contact us directly.',
      };
    }

    // Send notification to business email
    const businessResult = await resend.emails.send({
      from: fromEmail,
      to: businessEmail,
      replyTo: email, // Allow direct reply to customer
      subject: `New Quote Request from ${companyName} - ${contactPerson}`,
      react: QuoteNotificationTemplate({
        companyName,
        contactPerson,
        email,
        phone,
        country,
        city,
        industry,
        productDescription,
        quantity,
        deliveryTimeline,
        additionalRequirements,
        scheduledDate,
        scheduledTime,
        requestType,
      }),
    });

    if (businessResult.error) {
      console.error('Business email error:', businessResult.error);
      // Don't fail the request if business email fails (user already got confirmation)
      console.warn('Business notification failed but auto-reply succeeded');
    }

    return {
      success: true,
      messageId: businessResult.data?.id,
      sandboxMode: false,
    };
  } catch (error) {
    console.error('Email sending error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'An unexpected error occurred while sending emails',
    };
  }
}