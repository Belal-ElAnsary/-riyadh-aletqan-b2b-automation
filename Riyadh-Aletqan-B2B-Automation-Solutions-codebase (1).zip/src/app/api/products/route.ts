import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { products } from '@/db/schema';
import { eq, like, or, and, desc, sql } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get('id');

    // Single product fetch
    if (id) {
      if (!id || isNaN(parseInt(id))) {
        return NextResponse.json(
          { error: 'Valid ID is required', code: 'INVALID_ID' },
          { status: 400 }
        );
      }

      const product = await db
        .select()
        .from(products)
        .where(eq(products.id, parseInt(id)))
        .limit(1);

      if (product.length === 0) {
        return NextResponse.json(
          { error: 'Product not found' },
          { status: 404 }
        );
      }

      return NextResponse.json(product[0], { status: 200 });
    }

    // List with pagination and filtering
    const limit = Math.min(parseInt(searchParams.get('limit') ?? '10'), 100);
    const offset = parseInt(searchParams.get('offset') ?? '0');
    const search = searchParams.get('search');
    const category = searchParams.get('category');
    const brand = searchParams.get('brand');
    const voltageLevel = searchParams.get('voltageLevel');

    let query = db.select().from(products);
    const conditions = [];

    // Search across name, code, description, brand
    if (search) {
      conditions.push(
        or(
          like(products.name, `%${search}%`),
          like(products.code, `%${search}%`),
          like(products.description, `%${search}%`),
          like(products.brand, `%${search}%`)
        )
      );
    }

    // Filter by category
    if (category) {
      conditions.push(eq(products.category, category));
    }

    // Filter by brand
    if (brand) {
      conditions.push(eq(products.brand, brand));
    }

    // Filter by voltage level
    if (voltageLevel) {
      conditions.push(eq(products.voltageLevel, voltageLevel));
    }

    // Apply all conditions
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    // Apply sorting, pagination
    const results = await query
      .orderBy(desc(products.createdAt))
      .limit(limit)
      .offset(offset);

    return NextResponse.json(results, { status: 200 });
  } catch (error) {
    console.error('GET error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validate required fields
    const requiredFields = [
      'name',
      'code',
      'category',
      'brand',
      'price',
      'image',
      'description',
    ];

    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          {
            error: `${field} is required`,
            code: 'MISSING_REQUIRED_FIELD',
          },
          { status: 400 }
        );
      }
    }

    // Validate price is a number
    if (typeof body.price !== 'number' || body.price < 0) {
      return NextResponse.json(
        { error: 'Price must be a valid positive number', code: 'INVALID_PRICE' },
        { status: 400 }
      );
    }

    // Sanitize string inputs
    const sanitizedData = {
      name: body.name.trim(),
      code: body.code.trim(),
      category: body.category.trim(),
      brand: body.brand.trim(),
      price: body.price,
      image: body.image.trim(),
      description: body.description.trim(),
      inStock: body.inStock !== undefined ? body.inStock : true,
      stockCount: body.stockCount !== undefined ? body.stockCount : 0,
      priceType: body.priceType?.trim() || 'fixed',
      specifications: body.specifications || null,
      features: body.features || null,
      warranty: body.warranty?.trim() || null,
      datasheet: body.datasheet?.trim() || null,
      leadTime: body.leadTime?.trim() || null,
      voltageLevel: body.voltageLevel?.trim() || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const newProduct = await db
      .insert(products)
      .values(sanitizedData)
      .returning();

    return NextResponse.json(newProduct[0], { status: 201 });
  } catch (error) {
    console.error('POST error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json(
        { error: 'Valid ID is required', code: 'INVALID_ID' },
        { status: 400 }
      );
    }

    // Check if product exists
    const existingProduct = await db
      .select()
      .from(products)
      .where(eq(products.id, parseInt(id)))
      .limit(1);

    if (existingProduct.length === 0) {
      return NextResponse.json(
        { error: 'Product not found' },
        { status: 404 }
      );
    }

    const body = await request.json();

    // Prevent updating id and createdAt
    delete body.id;
    delete body.createdAt;

    // Build update object dynamically
    const updates: Record<string, any> = {};

    if (body.name !== undefined) updates.name = body.name.trim();
    if (body.code !== undefined) updates.code = body.code.trim();
    if (body.category !== undefined) updates.category = body.category.trim();
    if (body.brand !== undefined) updates.brand = body.brand.trim();
    if (body.price !== undefined) {
      if (typeof body.price !== 'number' || body.price < 0) {
        return NextResponse.json(
          { error: 'Price must be a valid positive number', code: 'INVALID_PRICE' },
          { status: 400 }
        );
      }
      updates.price = body.price;
    }
    if (body.image !== undefined) updates.image = body.image.trim();
    if (body.description !== undefined) updates.description = body.description.trim();
    if (body.inStock !== undefined) updates.inStock = body.inStock;
    if (body.stockCount !== undefined) updates.stockCount = body.stockCount;
    if (body.priceType !== undefined) updates.priceType = body.priceType.trim();
    if (body.specifications !== undefined) updates.specifications = body.specifications;
    if (body.features !== undefined) updates.features = body.features;
    if (body.warranty !== undefined) updates.warranty = body.warranty ? body.warranty.trim() : null;
    if (body.datasheet !== undefined) updates.datasheet = body.datasheet ? body.datasheet.trim() : null;
    if (body.leadTime !== undefined) updates.leadTime = body.leadTime ? body.leadTime.trim() : null;
    if (body.voltageLevel !== undefined) updates.voltageLevel = body.voltageLevel ? body.voltageLevel.trim() : null;

    // Always update timestamp - use SQL function for database timestamp
    updates.updatedAt = sql`CURRENT_TIMESTAMP`;

    const updatedProduct = await db
      .update(products)
      .set(updates)
      .where(eq(products.id, parseInt(id)))
      .returning();

    return NextResponse.json(updatedProduct[0], { status: 200 });
  } catch (error) {
    console.error('PUT error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const id = searchParams.get('id');

    if (!id || isNaN(parseInt(id))) {
      return NextResponse.json(
        { error: 'Valid ID is required', code: 'INVALID_ID' },
        { status: 400 }
      );
    }

    // Check if product exists
    const existingProduct = await db
      .select()
      .from(products)
      .where(eq(products.id, parseInt(id)))
      .limit(1);

    if (existingProduct.length === 0) {
      return NextResponse.json(
        { error: 'Product not found' },
        { status: 404 }
      );
    }

    const deletedProduct = await db
      .delete(products)
      .where(eq(products.id, parseInt(id)))
      .returning();

    return NextResponse.json(
      {
        message: 'Product deleted successfully',
        product: deletedProduct[0],
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('DELETE error:', error);
    return NextResponse.json(
      { error: 'Internal server error: ' + (error as Error).message },
      { status: 500 }
    );
  }
}