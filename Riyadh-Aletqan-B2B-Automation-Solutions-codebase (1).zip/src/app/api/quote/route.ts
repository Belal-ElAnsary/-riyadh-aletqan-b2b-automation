import { NextRequest, NextResponse } from 'next/server';
import { sendQuoteEmails, type QuoteFormData } from '@/app/actions/quote-email';

export async function POST(request: NextRequest) {
  try {
    console.log('=== Quote submission received ===');
    
    const body = await request.json();
    console.log('Request body:', JSON.stringify(body, null, 2));

    // Validate required fields
    const requiredFields = ['companyName', 'contactPerson', 'email', 'phone', 'country', 'city', 'productDescription'];
    const missingFields = requiredFields.filter(field => !body[field]);

    if (missingFields.length > 0) {
      console.error('Missing required fields:', missingFields);
      return NextResponse.json(
        { 
          success: false, 
          error: `Missing required fields: ${missingFields.join(', ')}` 
        },
        { status: 400 }
      );
    }

    // Prepare the form data
    const formData: QuoteFormData = {
      companyName: body.companyName,
      contactPerson: body.contactPerson,
      email: body.email,
      phone: body.phone,
      country: body.country,
      city: body.city,
      industry: body.industry || '',
      productDescription: body.productDescription,
      quantity: body.quantity || '',
      deliveryTimeline: body.deliveryTimeline || '',
      additionalRequirements: body.additionalRequirements || '',
      scheduledDate: body.scheduledDate,
      scheduledTime: body.scheduledTime,
      requestType: body.requestType,
    };

    console.log('Sending emails with data:', JSON.stringify(formData, null, 2));

    // Send the emails
    const result = await sendQuoteEmails(formData);

    console.log('Email send result:', result);

    if (!result.success) {
      console.error('Email sending failed:', result.error);
      return NextResponse.json(
        { 
          success: false, 
          error: result.error || 'Failed to send emails' 
        },
        { status: 500 }
      );
    }

    console.log('✅ Quote submission completed successfully');
    return NextResponse.json({
      success: true,
      messageId: result.messageId,
      message: 'Quote request submitted successfully',
    });

  } catch (error) {
    console.error('=== Quote submission error ===');
    console.error('Error:', error);
    console.error('Stack:', error instanceof Error ? error.stack : 'No stack trace');
    
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'An unexpected error occurred',
      },
      { status: 500 }
    );
  }
}
