"use client";

import Link from "next/link";
import * as React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  ArrowRight,
  Zap,
  Shield,
  Award,
  Cpu,
  Gauge,
  Radio,
  Lock,
  Cable,
  CheckCircle,
  Users,
  Globe,
  Wrench,
  Search,
  ChevronRight,
  Monitor,
  Cog,
  Settings,
  Box,
  Boxes,
  Building2,
  Handshake
} from "lucide-react";

interface Product {
  id: number;
  name: string;
  code: string;
  category: string;
  brand: string;
  price: number;
  image: string;
  description: string;
  inStock: boolean;
  stockCount: number;
  priceType: string;
  voltageLevel?: string | null;
}

export default function Home() {
  const [featuredProducts, setFeaturedProducts] = React.useState<Product[]>([]);
  const [isLoadingProducts, setIsLoadingProducts] = React.useState(true);

  React.useEffect(() => {
    fetchFeaturedProducts();
  }, []);

  const fetchFeaturedProducts = async () => {
    try {
      const response = await fetch("/api/products?limit=6");
      if (!response.ok) throw new Error("Failed to fetch products");
      const data = await response.json();
      setFeaturedProducts(data);
    } catch (error) {
      console.error("Error fetching products:", error);
    } finally {
      setIsLoadingProducts(false);
    }
  };

  const categories = [
    {
      name: "Power Supply",
      icon: Zap,
      description: "Power supplies & distribution",
      href: "/products",
      category: "Power"
    },
    {
      name: "HMIs-Industrial PCs",
      icon: Monitor,
      description: "Human Machine Interfaces & Industrial PCs",
      href: "/products",
      category: "HMI"
    },
    {
      name: "Modules",
      icon: Box,
      description: "I/O Modules & Expansion Units",
      href: "/products",
      category: "PLCs"
    },
    {
      name: "PLC Systems",
      icon: Cpu,
      description: "Programmable Logic Controllers",
      href: "/products",
      category: "PLCs"
    },
    {
      name: "Variable Frequency Drive",
      icon: Cog,
      description: "VFDs & Motor Control",
      href: "/products",
      category: "Drives"
    },
    {
      name: "Circuit Protection",
      icon: Shield,
      description: "Breakers & Protection Devices",
      href: "/products",
      category: "Power"
    },
    {
      name: "Industrial Communication",
      icon: Radio,
      description: "Networks & Protocols",
      href: "/products",
      category: "PLCs"
    },
    {
      name: "Industrial Softwares",
      icon: Settings,
      description: "Automation & SCADA Software",
      href: "/products",
      category: "HMI"
    },
    {
      name: "General Automation",
      icon: Boxes,
      description: "Automation Solutions",
      href: "/products",
      category: "PLCs"
    },
    {
      name: "Drives, Motors and Circuit Protection",
      icon: Gauge,
      description: "Complete Drive Systems",
      href: "/products",
      category: "Drives"
    },
    {
      name: "Sensors",
      icon: Radio,
      description: "Industrial Sensors & Measurement",
      href: "/products",
      category: "Sensors"
    },
    {
      name: "Safety Systems",
      icon: Lock,
      description: "Safety Relays & Emergency Stop",
      href: "/products",
      category: "Safety"
    }
  ];

  const brands = [
    { name: "ABB", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763629973154-9k5162jmrx.webp" },
    { name: "Siemens", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763892966098-ezsfkk4jaxl.png" },
    { name: "Schneider Electric", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763635314848-t0ejqbqpyp.jpg" },
    { name: "Allen-Bradley", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763893189686-ex3pucbelxv.png" },
    { name: "Delta", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763892344322-4nw3ko39s9g.png" },
    { name: "Omron", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763891363449-3cogxn63x2b.jpg" },
    { name: "Phoenix Contact", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763636136628-21dt21xmgsm.png" }
  ];

  // Duplicate brands for seamless loop
  const duplicatedBrands = [...brands, ...brands];

  const clients = [
    { name: "Saudi Binladin Group", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/saudi-binladin-group-logo-professional-c-83aaae56-20251123121110.jpg" },
    { name: "Nesma Trading", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/nesma-trading-company-logo-professional--22767e68-20251123121110.jpg" },
    { name: "Saudi Aramco", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/saudi-aramco-logo-iconic-saudi-oil-compa-8b95eda4-20251123121109.jpg" },
    { name: "SABIC", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/sabic-logo-saudi-basic-industries-corpor-ca95fe9b-20251123121110.jpg" },
    { name: "Saudi Electricity Company", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/saudi-electricity-company-sec-logo-profe-b725a4ad-20251123121110.jpg" },
    { name: "Ma'aden", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/ma-aden-mining-company-logo-saudi-arabia-6962b286-20251123121110.jpg" }
  ];

  const partners = [
    { name: "ABB", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763629973154-9k5162jmrx.webp" },
    { name: "Rockwell Automation", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763893189686-ex3pucbelxv.png" },
    { name: "Siemens", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763892966098-ezsfkk4jaxl.png" },
    { name: "Schneider Electric", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763635314848-t0ejqbqpyp.jpg" },
    { name: "Hanley Energy GCC", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/hanley-energy-gcc-company-logo-professio-ce433f64-20251123124545.jpg" },
    { name: "TMEIC Corporation", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/tmeic-corporation-logo-industrial-automa-765199a1-20251123124544.jpg" },
    { name: "DRA GLOBAL", logo: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/generated_images/dra-global-company-logo-professional-eng-9ee7b588-20251123124545.jpg" }
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section - Simplified */}
      <section className="relative bg-gradient-to-br from-primary via-primary/95 to-primary/90 text-primary-foreground border-b">
        <div className="absolute inset-0 bg-grid-white/[0.03] bg-[size:30px_30px]" />
        <div className="relative container mx-auto px-4 py-16 md:py-20">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground text-sm">
              Your Industrial Automation Partner
            </Badge>
            <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
              Professional Industrial Solutions
            </h1>
            <p className="text-lg md:text-xl mb-6 text-primary-foreground/90">
              Quality automation products from world-leading brands. Serving Saudi Arabia and the GCC.
            </p>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by product name, code, or brand..."
                  className="pl-12 h-14 text-base bg-background text-foreground"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      const query = e.currentTarget.value;
                      window.location.href = `/products?search=${encodeURIComponent(query)}`;
                    }
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brands Section - Auto Slider */}
      <section className="py-12 bg-muted/30 border-b overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">
              OUR <span className="text-primary">BRANDS</span>
            </h2>
          </div>

          {/* Auto-scrolling Brands */}
          <div className="relative">
            <div className="flex gap-4 animate-scroll">
              {duplicatedBrands.map((brand, index) => (
                <div 
                  key={`${brand.name}-${index}`} 
                  className="flex-shrink-0 bg-white rounded-lg p-6 flex items-center justify-center border border-border h-24 w-40 hover:shadow-md transition-shadow"
                >
                  <img
                    src={brand.logo}
                    alt={brand.name}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="text-center mt-6">
            <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
              View All Brands
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* Browse Categories Section */}
      <section className="py-12 border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                Browse <span className="text-primary">Our Catalog</span>
              </h2>
              <p className="text-muted-foreground">
                Explore our comprehensive range of industrial automation solutions
              </p>
            </div>
            <Button variant="outline" size="lg" asChild className="hidden md:flex">
              <Link href="/products">
                View All Products
                <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          {/* Categories Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 mb-6">
            {categories.map((category, index) => (
              <Link key={index} href={category.href}>
                <Card className="h-full hover:shadow-md hover:border-primary/50 transition-all cursor-pointer group">
                  <CardContent className="p-6 flex flex-col items-center text-center space-y-3">
                    <div className="h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <category.icon className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-sm mb-1 group-hover:text-primary transition-colors">
                        {category.name}
                      </h3>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {category.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          <Button variant="outline" size="lg" asChild className="w-full md:hidden">
            <Link href="/products">
              View All Products
              <ChevronRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="py-12 border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">
              FEATURED <span className="text-primary">PRODUCTS</span>
            </h2>
            <Button variant="link" asChild className="text-primary hidden md:flex">
              <Link href="/products">
                View All
                <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          {isLoadingProducts ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="h-80 animate-pulse">
                  <div className="h-48 bg-muted" />
                  <CardHeader>
                    <div className="h-4 bg-muted rounded w-3/4 mb-2" />
                    <div className="h-3 bg-muted rounded w-1/2" />
                  </CardHeader>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProducts.map((product) => (
                <Link key={product.id} href={`/products/${product.id}`}>
                  <Card className="h-full hover:shadow-lg transition-all group cursor-pointer border hover:border-primary/50">
                    <div className="relative h-48 overflow-hidden rounded-t-lg bg-muted">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      {product.inStock ? (
                        <Badge className="absolute top-2 right-2 bg-green-600">
                          Available
                        </Badge>
                      ) : (
                        <Badge className="absolute top-2 right-2 bg-destructive">
                          Out of Stock
                        </Badge>
                      )}
                      {product.voltageLevel && (
                        <Badge className="absolute bottom-2 left-2 bg-primary/90 backdrop-blur-sm flex items-center gap-1">
                          <Zap className="h-3 w-3" />
                          {product.voltageLevel}
                        </Badge>
                      )}
                    </div>
                    <CardHeader>
                      <div className="mb-2">
                        <Badge variant="outline" className="text-xs">
                          {product.brand}
                        </Badge>
                      </div>
                      <CardTitle className="text-base line-clamp-2 group-hover:text-primary transition-colors">
                        {product.name}
                      </CardTitle>
                      <CardDescription className="text-xs">
                        Stock No: {product.code}
                      </CardDescription>
                      <CardDescription className="text-xs">
                        Man No: {product.code}
                      </CardDescription>
                    </CardHeader>
                  </Card>
                </Link>
              ))}
            </div>
          )}

          <div className="text-center mt-8">
            <Button size="lg" asChild>
              <Link href="/products">
                View All Products
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Clients & Partnerships Section */}
      <section className="py-12 border-b">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                CLIENTS & <span className="text-primary">PARTNERSHIPS</span>
              </h2>
              <p className="text-muted-foreground">
                Trusted by leading organizations across Saudi Arabia and the GCC
              </p>
            </div>
          </div>

          {/* Our Clients Subsection */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Building2 className="h-5 w-5 text-primary" />
              <h3 className="text-xl font-semibold">Our Clients</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
              {clients.map((client, index) => (
                <div key={index} className="bg-white rounded-lg p-6 flex items-center justify-center hover:shadow-md transition-shadow border border-border h-28">
                  <img
                    src={client.logo}
                    alt={client.name}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Our Partners Subsection */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Handshake className="h-5 w-5 text-primary" />
              <h3 className="text-xl font-semibold">Our Strategic Partners</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Proudly serving as the trusted local contractor supporting international partners in key Saudi projects.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
              {partners.map((partner, index) => (
                <div key={index} className="bg-white rounded-lg p-6 flex items-center justify-center hover:shadow-md transition-shadow border border-border h-28">
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-12 border-b">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold mb-3">
              Why Choose <span className="text-primary">Riyadh Aletqan</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Your trusted partner for industrial automation and electrical solutions in the GCC
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center border-2">
              <CardContent className="pt-6">
                <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">12-Month Warranty</h3>
                <p className="text-sm text-muted-foreground">
                  Comprehensive warranty coverage on all products
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2">
              <CardContent className="pt-6">
                <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Award className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Authorized Distributor</h3>
                <p className="text-sm text-muted-foreground">
                  Official partner for world-leading brands
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2">
              <CardContent className="pt-6">
                <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Quality Assured</h3>
                <p className="text-sm text-muted-foreground">
                  ISO 9001:2015 certified with genuine products
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2">
              <CardContent className="pt-6">
                <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Users className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Expert Support</h3>
                <p className="text-sm text-muted-foreground">
                  Technical support with 15+ years experience
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold mb-3">
              Our <span className="text-primary">Services</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Complete solutions from product supply to installation and maintenance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <Wrench className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Annual Maintenance</CardTitle>
                <CardDescription className="text-sm">
                  Comprehensive AMC programs for your equipment
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="link" className="p-0 h-auto" asChild>
                  <Link href="/services/amc">
                    Learn More <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <Settings className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Installation Services</CardTitle>
                <CardDescription className="text-sm">
                  Professional installation by certified engineers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="link" className="p-0 h-auto" asChild>
                  <Link href="/services/installation">
                    Learn More <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Calibration Services</CardTitle>
                <CardDescription className="text-sm">
                  Precision calibration for measurement devices
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="link" className="p-0 h-auto" asChild>
                  <Link href="/services/calibration">
                    Learn More <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <Boxes className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Turnkey Projects</CardTitle>
                <CardDescription className="text-sm">
                  End-to-end project delivery solutions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="link" className="p-0 h-auto" asChild>
                  <Link href="/turnkey-projects">
                    Learn More <ArrowRight className="ml-2 h-3 w-3" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary via-primary/95 to-primary/90 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-4xl font-bold mb-4">
            Ready to Start Your Project?
          </h2>
          <p className="text-lg md:text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
            Get personalized consultation and competitive quotes from our expert team
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
              <Link href="/request-quote">
                Request a Quote
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
              <Link href="/partner">
                Become a Partner
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  );
}