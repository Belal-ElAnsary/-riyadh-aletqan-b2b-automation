"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, CreditCard, Building2, DollarSign, Lock, CheckCircle } from "lucide-react";

export default function PaymentsPage() {
  const paymentMethods = [
    {
      icon: CreditCard,
      name: "Credit/Debit Cards",
      description: "Visa, Mastercard, American Express",
      features: ["Instant processing", "Secure 3D verification", "International cards accepted"]
    },
    {
      icon: Building2,
      name: "Bank Transfer",
      description: "Direct bank transfer (SWIFT/IBAN)",
      features: ["Ideal for large orders", "2-3 business days processing", "Invoice provided"]
    },
    {
      icon: DollarSign,
      name: "Purchase Orders",
      description: "For corporate and government clients",
      features: ["Credit terms available", "Net 30/60 payment terms", "Account approval required"]
    }
  ];

  const securityFeatures = [
    "PCI DSS compliant payment processing",
    "SSL encryption for all transactions",
    "3D Secure authentication",
    "Fraud detection and prevention",
    "No storage of card details",
    "Regular security audits"
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Shield className="h-12 w-12 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Secure Payments
            </h1>
            <p className="text-xl text-primary-foreground/90">
              Safe, secure, and convenient payment options for your peace of mind
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Payment Methods */}
          <section>
            <h2 className="text-3xl font-bold mb-6">Accepted Payment Methods</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {paymentMethods.map((method, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <method.icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle>{method.name}</CardTitle>
                    <CardDescription>{method.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {method.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Security */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Payment Security
              </CardTitle>
              <CardDescription>Your security is our top priority</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                We use industry-leading security measures to protect your payment information. All transactions are encrypted and processed through secure payment gateways.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {securityFeatures.map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Currency & Pricing */}
          <Card>
            <CardHeader>
              <CardTitle>Currency & Pricing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div>
                <h3 className="font-semibold mb-2">Pricing Currency</h3>
                <p className="text-muted-foreground">
                  All prices are displayed in Saudi Riyals (SAR). Prices exclude VAT unless otherwise stated. VAT will be calculated and displayed at checkout.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">International Payments</h3>
                <p className="text-muted-foreground">
                  International credit cards are accepted. Currency conversion will be handled by your card issuer at their exchange rate.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Price Validity</h3>
                <p className="text-muted-foreground">
                  Prices are subject to change without notice. The price confirmed in your order confirmation email is the final price.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Corporate Accounts */}
          <Card>
            <CardHeader>
              <CardTitle>Corporate Payment Terms</CardTitle>
              <CardDescription>Flexible payment options for business customers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <p>
                We offer flexible payment terms for registered corporate customers, including:
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>Net 30/60 payment terms upon credit approval</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>Purchase order (PO) processing</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>Dedicated account management</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>Volume discounts for bulk orders</span>
                </li>
              </ul>
              <p className="text-muted-foreground pt-2">
                To set up a corporate account, please contact our sales team at sales@riyadhaletqan.com
              </p>
            </CardContent>
          </Card>

          {/* Payment Issues */}
          <Card className="bg-muted/30">
            <CardHeader>
              <CardTitle>Payment Issues?</CardTitle>
            </CardHeader>
            <CardContent className="text-sm">
              <p className="text-muted-foreground mb-4">
                If you experience any issues during payment, please contact our support team:
              </p>
              <p>
                <strong>Email:</strong> payments@riyadhaletqan.com<br />
                <strong>Phone:</strong> +966 12 345 6789<br />
                <strong>Hours:</strong> Sunday - Thursday, 8:00 AM - 5:00 PM
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
