"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ShoppingCart, 
  FileText, 
  Shield, 
  Truck, 
  CheckCircle, 
  Download,
  ChevronLeft,
  Minus,
  Plus
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

const productsData = [
  {
    id: "1",
    name: "Siemens SINAMICS G120C",
    code: "6SL3210-1KE21-3UB2",
    category: "Drives & Motors",
    brand: "Siemens",
    price: 1250,
    image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop",
    description: "The SINAMICS G120C is a compact frequency inverter for industrial applications. It combines outstanding functionality with ease of use and rugged construction.",
    inStock: true,
    stockCount: 12,
    priceType: "fixed",
    specifications: {
      "Power Rating": "7.5 kW",
      "Voltage": "380-480V AC",
      "Current": "18A",
      "Frequency": "0-550 Hz",
      "Protection Class": "IP20",
      "Weight": "2.8 kg",
      "Dimensions": "185 x 275 x 195 mm",
      "Cooling": "Natural convection"
    },
    features: [
      "Easy commissioning with Basic Operator Panel (BOP-2)",
      "Integrated safety functions STO (Safe Torque Off)",
      "USS, Modbus RTU communication protocols",
      "Energy saving through eco mode",
      "Overload capability 150% for 60s"
    ],
    warranty: "24 months manufacturer warranty",
    datasheet: "/datasheets/siemens-g120c.pdf",
    leadTime: "2-3 business days"
  },
  {
    id: "2",
    name: "Schneider Electric Altivar ATV320",
    code: "ATV320U75N4B",
    category: "Drives & Motors",
    brand: "Schneider Electric",
    price: 980,
    image: "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop",
    description: "Altivar ATV320 variable speed drive is designed for simple machines in industrial and commercial applications.",
    inStock: true,
    stockCount: 8,
    priceType: "fixed",
    specifications: {
      "Power Rating": "7.5 kW",
      "Voltage": "380-500V AC",
      "Current": "16.7A",
      "Frequency": "0-500 Hz",
      "Protection Class": "IP20",
      "Weight": "2.5 kg",
      "Dimensions": "180 x 268 x 195 mm"
    },
    features: [
      "Compact design saves space",
      "Built-in Modbus and CANopen",
      "Integrated EMC filter",
      "Auto-tuning for optimal performance",
      "Energy savings up to 30%"
    ],
    warranty: "18 months manufacturer warranty",
    datasheet: "/datasheets/schneider-atv320.pdf",
    leadTime: "1-2 business days"
  },
  {
    id: "3",
    name: "Siemens SIMATIC S7-1200",
    code: "6ES7214-1AG40-0XB0",
    category: "PLCs & Controllers",
    brand: "Siemens",
    price: 2450,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop",
    description: "The SIMATIC S7-1200 is a compact PLC perfectly suited for small automation tasks with integrated I/O and communication interfaces.",
    inStock: true,
    stockCount: 5,
    priceType: "fixed",
    specifications: {
      "CPU": "CPU 1214C DC/DC/DC",
      "Memory": "50 KB work memory",
      "Digital Inputs": "14",
      "Digital Outputs": "10",
      "Analog Inputs": "2",
      "Protection Class": "IP20",
      "Operating Voltage": "24V DC"
    },
    features: [
      "Integrated Ethernet/PROFINET interface",
      "Modular expansion capability",
      "Integrated technology functions",
      "High-speed counters and pulse outputs",
      "TIA Portal programming environment"
    ],
    warranty: "36 months manufacturer warranty",
    datasheet: "/datasheets/siemens-s7-1200.pdf",
    leadTime: "3-5 business days"
  },
  {
    id: "4",
    name: "ABB PLC PM554-TP",
    code: "1SAP120600R0071",
    category: "PLCs & Controllers",
    brand: "ABB",
    price: 3200,
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop",
    description: "ABB AC500 programmable controller with integrated touchscreen for enhanced machine control and monitoring.",
    inStock: false,
    stockCount: 0,
    priceType: "quote",
    specifications: {
      "CPU": "PM554 with touchscreen",
      "Memory": "256 KB program, 512 KB data",
      "Display": "5.7\" TFT color",
      "Digital I/O": "Expandable",
      "Communication": "Ethernet, RS-485",
      "Protection Class": "IP65 front"
    },
    features: [
      "Integrated HMI reduces costs",
      "IEC 61131-3 programming",
      "Web server functionality",
      "Multiple protocol support",
      "Rugged industrial design"
    ],
    warranty: "24 months manufacturer warranty",
    datasheet: "/datasheets/abb-pm554.pdf",
    leadTime: "4-6 weeks (contact for availability)"
  },
  {
    id: "5",
    name: "Omron E3Z Photoelectric Sensor",
    code: "E3Z-D87",
    category: "Sensors",
    brand: "Omron",
    price: 145,
    image: "https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=800&h=800&fit=crop",
    description: "High-precision photoelectric sensor with excellent performance in demanding industrial environments.",
    inStock: true,
    stockCount: 45,
    priceType: "fixed",
    specifications: {
      "Detection Range": "30m (reflective)",
      "Light Source": "Red LED",
      "Response Time": "1ms",
      "Output": "NPN/PNP selectable",
      "Protection Class": "IP67",
      "Operating Voltage": "12-24V DC",
      "Cable Length": "2m"
    },
    features: [
      "Long sensing range up to 30m",
      "High immunity to ambient light",
      "Easy optical axis alignment",
      "Robust metal housing",
      "Temperature compensation"
    ],
    warranty: "12 months manufacturer warranty",
    datasheet: "/datasheets/omron-e3z.pdf",
    leadTime: "Same day dispatch"
  }
];

export default function ProductDetailPage() {
  const params = useParams();
  const productId = params.id as string;
  const [quantity, setQuantity] = useState(1);

  const product = productsData.find(p => p.id === productId) || productsData[0];

  const incrementQuantity = () => setQuantity(prev => prev + 1);
  const decrementQuantity = () => setQuantity(prev => Math.max(1, prev - 1));

  return (
    <main className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <section className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-muted-foreground hover:text-primary">
              Home
            </Link>
            <span className="text-muted-foreground">/</span>
            <Link href="/products" className="text-muted-foreground hover:text-primary">
              Products
            </Link>
            <span className="text-muted-foreground">/</span>
            <span className="font-medium">{product.name}</span>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" className="mb-6" asChild>
          <Link href="/products">
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Products
          </Link>
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Product Image */}
          <div>
            <div className="relative aspect-square rounded-lg overflow-hidden bg-muted border-2">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {!product.inStock && (
                <Badge className="absolute top-4 right-4 bg-destructive text-lg px-4 py-2">
                  Out of Stock
                </Badge>
              )}
              {product.priceType === "quote" && (
                <Badge className="absolute top-4 left-4 bg-secondary text-lg px-4 py-2">
                  RFQ Only
                </Badge>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="mb-4">
              <Badge variant="outline" className="mb-2">{product.brand}</Badge>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">{product.name}</h1>
              <p className="text-muted-foreground">
                Product Code: <span className="font-mono font-semibold">{product.code}</span>
              </p>
            </div>

            <Separator className="my-4" />

            {/* Price */}
            <div className="mb-6">
              {product.priceType === "fixed" ? (
                <>
                  <p className="text-4xl font-bold text-primary mb-2">
                    ${product.price.toLocaleString()}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Price excludes VAT and shipping
                  </p>
                </>
              ) : (
                <div className="bg-muted p-4 rounded-lg">
                  <p className="text-xl font-semibold mb-2">Request for Quote</p>
                  <p className="text-sm text-muted-foreground">
                    Contact us for pricing and availability information
                  </p>
                </div>
              )}
            </div>

            {/* Stock Status */}
            <div className="mb-6">
              {product.inStock ? (
                <div className="flex items-center gap-2 text-green-600">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-semibold">In Stock ({product.stockCount} available)</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-destructive">
                  <span className="font-semibold">Currently Out of Stock</span>
                </div>
              )}
              <p className="text-sm text-muted-foreground mt-1">
                <Truck className="inline h-4 w-4 mr-1" />
                Lead Time: {product.leadTime}
              </p>
            </div>

            {/* Description */}
            <p className="text-base mb-6 leading-relaxed">{product.description}</p>

            {/* Quantity and Actions */}
            {product.priceType === "fixed" && product.inStock ? (
              <div className="space-y-4 mb-6">
                <div className="flex items-center gap-4">
                  <label className="font-semibold">Quantity:</label>
                  <div className="flex items-center border rounded-md">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={decrementQuantity}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="px-6 py-2 font-semibold">{quantity}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={incrementQuantity}
                      disabled={quantity >= product.stockCount}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button size="lg" className="flex-1">
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Add to Cart
                  </Button>
                  <Button size="lg" variant="outline" className="flex-1" asChild>
                    <Link href={`/request-quote?product=${product.id}`}>
                      <FileText className="mr-2 h-5 w-5" />
                      Request Quote
                    </Link>
                  </Button>
                </div>
                
                {/* Support Text Below Action Buttons */}
                <div className="text-center pt-2">
                  <p className="text-xs text-muted-foreground mb-1">
                    Do you already have this product and need support?
                  </p>
                  <Link 
                    href="/request-quote?service=technical-support" 
                    className="text-xs text-primary hover:underline"
                  >
                    Request Technical Support
                  </Link>
                </div>
              </div>
            ) : (
              <div className="mb-6">
                <Button size="lg" className="w-full mb-4" asChild>
                  <Link href={`/request-quote?product=${product.id}`}>
                    <FileText className="mr-2 h-5 w-5" />
                    Request Quote for this Product
                  </Link>
                </Button>
                
                {/* Support Text Below Action Button */}
                <div className="text-center">
                  <p className="text-xs text-muted-foreground mb-1">
                    Do you already have this product and need support?
                  </p>
                  <Link 
                    href="/request-quote?service=technical-support" 
                    className="text-xs text-primary hover:underline"
                  >
                    Request Technical Support
                  </Link>
                </div>
              </div>
            )}

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-4 pt-6 border-t">
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <p className="font-semibold text-sm">Genuine Products</p>
                  <p className="text-xs text-muted-foreground">{product.warranty}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Truck className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <p className="font-semibold text-sm">Fast Delivery</p>
                  <p className="text-xs text-muted-foreground">GCC-wide shipping</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <Tabs defaultValue="specifications" className="mb-12">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="downloads">Downloads</TabsTrigger>
          </TabsList>
          
          <TabsContent value="specifications" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Technical Specifications</CardTitle>
                <CardDescription>Detailed product specifications and ratings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between items-center py-2 border-b">
                      <span className="font-medium text-sm">{key}</span>
                      <span className="text-sm text-muted-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="features" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Key Features & Benefits</CardTitle>
                <CardDescription>What makes this product stand out</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="downloads" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Product Documentation</CardTitle>
                <CardDescription>Download datasheets, manuals, and certificates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Download className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-semibold">Product Datasheet</p>
                        <p className="text-sm text-muted-foreground">PDF, 2.3 MB</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Download
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Download className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-semibold">Installation Manual</p>
                        <p className="text-sm text-muted-foreground">PDF, 4.1 MB</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Download
                    </Button>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <Download className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-semibold">Warranty Certificate</p>
                        <p className="text-sm text-muted-foreground">PDF, 0.8 MB</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Download
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Support Section */}
        <Card className="bg-muted/30">
          <CardHeader>
            <CardTitle>Need Assistance?</CardTitle>
            <CardDescription>Our technical team is here to help</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <p className="font-semibold mb-1">Technical Support</p>
                <p className="text-sm text-muted-foreground">Get expert guidance</p>
                <Button variant="link" className="mt-2" asChild>
                  <Link href="/request-quote?service=technical-support">Contact Support</Link>
                </Button>
              </div>
              <div className="text-center">
                <p className="font-semibold mb-1">Request Quote</p>
                <p className="text-sm text-muted-foreground">Volume discounts available</p>
                <Button variant="link" className="mt-2" asChild>
                  <Link href={`/request-quote?product=${product.id}`}>Get Quote</Link>
                </Button>
              </div>
              <div className="text-center">
                <p className="font-semibold mb-1">Installation Service</p>
                <p className="text-sm text-muted-foreground">Professional installation</p>
                <Button variant="link" className="mt-2" asChild>
                  <Link href="/services/installation">Learn More</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}