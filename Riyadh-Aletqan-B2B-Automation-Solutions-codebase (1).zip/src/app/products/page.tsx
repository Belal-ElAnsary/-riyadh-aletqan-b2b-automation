"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, ShoppingCart, FileText, Loader2, Settings, Filter, ChevronRight, Zap } from "lucide-react";
import { useSession } from "@/lib/auth-client";

interface Product {
  id: number;
  name: string;
  code: string;
  category: string;
  brand: string;
  price: number;
  image: string;
  description: string;
  inStock: boolean;
  stockCount: number;
  priceType: string;
  voltageLevel?: string | null;
}

interface Category {
  name: string;
  value: string;
  subcategories: string[];
}

export default function ProductsPage() {
  const { data: session, isPending } = useSession();
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedSubcategories, setSelectedSubcategories] = useState<string[]>([]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedVoltageLevels, setSelectedVoltageLevels] = useState<string[]>([]);
  const [selectedPriceRange, setSelectedPriceRange] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState("name");
  const [hoveredCategory, setHoveredCategory] = useState<string>("Drives");
  const [showCategoryBrowser, setShowCategoryBrowser] = useState(true);

  const categories: Category[] = [
    {
      name: "DRIVES & MOTORS",
      value: "Drives",
      subcategories: [
        "Variable Frequency Drives",
        "Servo Drives",
        "DC Drives",
        "Soft Starters",
        "Motor Starters",
        "Motor Protection"
      ]
    },
    {
      name: "PLCs & CONTROLLERS",
      value: "PLCs",
      subcategories: [
        "Programmable Logic Controllers",
        "PAC Systems",
        "Remote I/O",
        "Expansion Modules",
        "Control Panels",
        "Industrial PCs"
      ]
    },
    {
      name: "SENSORS",
      value: "Sensors",
      subcategories: [
        "Proximity Sensors",
        "Photoelectric Sensors",
        "Ultrasonic Sensors",
        "Pressure Sensors",
        "Temperature Sensors",
        "Flow Sensors"
      ]
    },
    {
      name: "SAFETY SYSTEMS",
      value: "Safety",
      subcategories: [
        "Safety Relays",
        "Light Curtains",
        "Safety Switches",
        "Emergency Stop Devices",
        "Safety PLCs",
        "Safety Mats"
      ]
    },
    {
      name: "POWER DISTRIBUTION",
      value: "Power",
      subcategories: [
        "Circuit Breakers",
        "Contactors",
        "Overload Relays",
        "Distribution Panels",
        "Power Supplies",
        "Transformers"
      ]
    },
    {
      name: "HMI & SCADA",
      value: "HMI",
      subcategories: [
        "Touch Panels",
        "Operator Interfaces",
        "SCADA Software",
        "Industrial Monitors",
        "Panel PCs",
        "Remote Access"
      ]
    }
  ];

  // Category images mapping
  const categoryImages: Record<string, string> = {
    "Drives": "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop",
    "PLCs": "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop",
    "Sensors": "https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=800&h=800&fit=crop",
    "Safety": "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=800&h=800&fit=crop",
    "Power": "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800&h=800&fit=crop",
    "HMI": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=800&fit=crop"
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setIsLoading(true);
    try {
      const response = await fetch("/api/products?limit=100");
      if (!response.ok) throw new Error("Failed to fetch products");
      const data = await response.json();
      setProducts(data);
    } catch (error) {
      console.error("Error fetching products:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Get unique brands from products
  const uniqueBrands = Array.from(new Set(products.map(p => p.brand))).sort();

  // Price range options
  const priceRanges = [
    { label: "All Prices", value: null, min: 0, max: Infinity },
    { label: "Under $100", value: "under-100", min: 0, max: 100 },
    { label: "$100 - $500", value: "100-500", min: 100, max: 500 },
    { label: "$500 - $1,000", value: "500-1000", min: 500, max: 1000 },
    { label: "$1,000 - $5,000", value: "1000-5000", min: 1000, max: 5000 },
    { label: "Over $5,000", value: "over-5000", min: 5000, max: Infinity },
  ];

  const filteredProducts = products
    .filter(product => {
      // Category filter
      if (selectedCategories.length > 0 && !selectedCategories.includes(product.category)) return false;
      
      // Brand filter
      if (selectedBrands.length > 0 && !selectedBrands.includes(product.brand)) return false;
      
      // Voltage Level filter
      if (selectedVoltageLevels.length > 0) {
        if (!product.voltageLevel || !selectedVoltageLevels.includes(product.voltageLevel)) return false;
      }
      
      // Price range filter
      if (selectedPriceRange) {
        const range = priceRanges.find(r => r.value === selectedPriceRange);
        if (range && product.priceType === "fixed") {
          if (product.price < range.min || product.price > range.max) return false;
        }
      }
      
      if (searchQuery && !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !product.code.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !product.brand.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name);
      if (sortBy === "price-low") return a.price - b.price;
      if (sortBy === "price-high") return b.price - a.price;
      return 0;
    });

  const clearAllFilters = () => {
    setSelectedCategories([]);
    setSelectedSubcategories([]);
    setSelectedBrands([]);
    setSelectedVoltageLevels([]);
    setSelectedPriceRange(null);
    setSearchQuery("");
  };

  const handleCategoryToggle = (categoryValue: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryValue)
        ? prev.filter(c => c !== categoryValue)
        : [...prev, categoryValue]
    );
  };

  const handleBrandToggle = (brand: string) => {
    setSelectedBrands(prev => 
      prev.includes(brand)
        ? prev.filter(b => b !== brand)
        : [...prev, brand]
    );
  };

  const handleVoltageLevelToggle = (level: string) => {
    setSelectedVoltageLevels(prev => 
      prev.includes(level)
        ? prev.filter(v => v !== level)
        : [...prev, level]
    );
  };

  const handleSubcategoryClick = (subcategory: string) => {
    setShowCategoryBrowser(false);
    setSelectedSubcategories([subcategory]);
    const category = categories.find(c => c.subcategories.includes(subcategory));
    if (category) {
      setSelectedCategories([category.value]);
    }
  };

  const handleCategoryImageClick = (categoryValue: string) => {
    setShowCategoryBrowser(false);
    setSelectedCategories([categoryValue]);
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-muted/30 border-b">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Industrial Products</h1>
          <p className="text-muted-foreground">
            Browse our comprehensive catalog of automation and electrical solutions
          </p>
        </div>
      </section>

      {/* Category Browser Section */}
      {showCategoryBrowser && (
        <section className="border-b bg-background">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Browse by Category</h2>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowCategoryBrowser(false)}
              >
                View All Products →
              </Button>
            </div>
            
            <Card className="overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[500px]">
                {/* Categories List - Left Side */}
                <div className="lg:col-span-3 border-r bg-muted/30">
                  <div className="p-2">
                    {categories.map((category) => (
                      <button
                        key={category.value}
                        className={`w-full text-left px-4 py-4 rounded-lg transition-all font-semibold text-sm ${
                          hoveredCategory === category.value
                            ? "bg-primary text-primary-foreground shadow-sm"
                            : "hover:bg-muted"
                        }`}
                        onMouseEnter={() => setHoveredCategory(category.value)}
                        onClick={() => handleCategoryImageClick(category.value)}
                      >
                        {category.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Subcategories - Middle Section */}
                <div className="lg:col-span-6 p-8">
                  <h3 className="text-xl font-bold mb-6 text-primary">
                    {categories.find(c => c.value === hoveredCategory)?.name}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {categories
                      .find(c => c.value === hoveredCategory)
                      ?.subcategories.map((subcategory) => (
                        <button
                          key={subcategory}
                          onClick={() => handleSubcategoryClick(subcategory)}
                          className="text-left px-4 py-3 rounded-md hover:bg-muted transition-colors group flex items-center justify-between"
                        >
                          <span className="text-sm font-medium group-hover:text-primary">
                            {subcategory}
                          </span>
                          <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </button>
                      ))}
                  </div>
                </div>

                {/* Product Image - Right Side */}
                <div className="lg:col-span-3 bg-muted/50 p-8 flex items-center justify-center">
                  <div className="relative w-full h-full flex items-center justify-center">
                    <img
                      src={categoryImages[hoveredCategory]}
                      alt={categories.find(c => c.value === hoveredCategory)?.name}
                      className="max-w-full max-h-[400px] object-contain rounded-lg shadow-lg transition-all duration-300"
                    />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </section>
      )}

      <div className="container mx-auto px-4 py-8">
        {!showCategoryBrowser && (
          <Button 
            variant="outline" 
            size="sm" 
            className="mb-6"
            onClick={() => {
              setShowCategoryBrowser(true);
              clearAllFilters();
            }}
          >
            ← Back to Category Browser
          </Button>
        )}

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <aside className="w-full lg:w-80 flex-shrink-0">
            <Card>
              <CardHeader className="bg-muted border-b">
                <div className="flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  <CardTitle>Filters</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Category Filter with Checkboxes */}
                <div>
                  <h3 className="font-semibold text-sm mb-3">Category</h3>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {categories.map((category) => (
                      <div key={category.value} className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id={`category-${category.value}`}
                            checked={selectedCategories.includes(category.value)}
                            onCheckedChange={() => handleCategoryToggle(category.value)}
                          />
                          <label
                            htmlFor={`category-${category.value}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            {category.name}
                          </label>
                        </div>
                        {/* Subcategories */}
                        {selectedCategories.includes(category.value) && (
                          <div className="ml-6 space-y-2 mt-2">
                            {category.subcategories.map((sub) => (
                              <div key={sub} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`sub-${sub}`}
                                  checked={selectedSubcategories.includes(sub)}
                                  onCheckedChange={(checked) => {
                                    setSelectedSubcategories(prev =>
                                      checked
                                        ? [...prev, sub]
                                        : prev.filter(s => s !== sub)
                                    );
                                  }}
                                />
                                <label
                                  htmlFor={`sub-${sub}`}
                                  className="text-xs text-muted-foreground leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                                >
                                  {sub}
                                </label>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Voltage Level Filter */}
                <div>
                  <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    Voltage Level
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="voltage-lv"
                        checked={selectedVoltageLevels.includes("LV")}
                        onCheckedChange={() => handleVoltageLevelToggle("LV")}
                      />
                      <label
                        htmlFor="voltage-lv"
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        LV (Low Voltage)
                      </label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="voltage-mv"
                        checked={selectedVoltageLevels.includes("MV")}
                        onCheckedChange={() => handleVoltageLevelToggle("MV")}
                      />
                      <label
                        htmlFor="voltage-mv"
                        className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        MV (Medium Voltage)
                      </label>
                    </div>
                  </div>
                </div>

                {/* Brand Filter with Checkboxes */}
                <div>
                  <h3 className="font-semibold text-sm mb-3">Brand</h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {uniqueBrands.map((brand) => (
                      <div key={brand} className="flex items-center space-x-2">
                        <Checkbox
                          id={`brand-${brand}`}
                          checked={selectedBrands.includes(brand)}
                          onCheckedChange={() => handleBrandToggle(brand)}
                        />
                        <label
                          htmlFor={`brand-${brand}`}
                          className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                        >
                          {brand}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Range Filter */}
                <div>
                  <h3 className="font-semibold text-sm mb-3">Price Range</h3>
                  <Select 
                    value={selectedPriceRange || "all-prices"} 
                    onValueChange={(value) => {
                      setSelectedPriceRange(value === "all-prices" ? null : value);
                    }}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="All Prices" />
                    </SelectTrigger>
                    <SelectContent>
                      {priceRanges.map((range) => (
                        <SelectItem key={range.value || "all-prices"} value={range.value || "all-prices"}>
                          {range.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Clear Filters Button */}
                {(selectedCategories.length > 0 || selectedBrands.length > 0 || selectedVoltageLevels.length > 0 || selectedPriceRange || searchQuery) && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={clearAllFilters}
                  >
                    Clear All Filters
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Active Filters Display */}
            {(selectedCategories.length > 0 || selectedBrands.length > 0 || selectedVoltageLevels.length > 0 || selectedPriceRange) && (
              <Card className="mt-4">
                <CardContent className="p-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-3">ACTIVE FILTERS</p>
                  <div className="space-y-2">
                    {selectedCategories.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-xs text-muted-foreground">Categories:</span>
                        <div className="flex flex-wrap gap-1">
                          {selectedCategories.map(cat => (
                            <Badge key={cat} variant="secondary" className="text-xs">
                              {categories.find(c => c.value === cat)?.name}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {selectedVoltageLevels.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-xs text-muted-foreground">Voltage Level:</span>
                        <div className="flex flex-wrap gap-1">
                          {selectedVoltageLevels.map(level => (
                            <Badge key={level} variant="secondary" className="text-xs flex items-center gap-1">
                              <Zap className="h-3 w-3" />
                              {level}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {selectedBrands.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-xs text-muted-foreground">Brands:</span>
                        <div className="flex flex-wrap gap-1">
                          {selectedBrands.map(brand => (
                            <Badge key={brand} variant="secondary" className="text-xs">
                              {brand}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {selectedPriceRange && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Price:</span>
                        <Badge variant="secondary">
                          {priceRanges.find(r => r.value === selectedPriceRange)?.label}
                        </Badge>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </aside>

          {/* Main Content */}
          <div className="flex-1">
            {/* Search and Sort Bar */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search by product, code, or brand..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* Sort Dropdown */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-[200px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Sort by Name</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Results Count */}
            <div className="mb-4">
              <p className="text-sm text-muted-foreground">
                {isLoading ? "Loading products..." : `Showing ${filteredProducts.length} of ${products.length} products`}
              </p>
            </div>

            {/* Product Grid */}
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="space-y-6">
                <Card className="p-12 text-center">
                  <p className="text-muted-foreground">No products found matching your criteria.</p>
                  <Button
                    variant="link"
                    onClick={clearAllFilters}
                  >
                    Clear all filters
                  </Button>
                </Card>
                
                {/* RFQ CTA for No Results */}
                <Card className="bg-muted/50 border-primary/20">
                  <CardContent className="p-8 text-center">
                    <FileText className="h-12 w-12 text-primary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">
                      Didn't find what you're looking for?
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Submit a Request for Quotation and we'll get back to you with the best solution.
                    </p>
                    <Button size="lg" asChild>
                      <Link href="/request-quote">
                        <FileText className="h-5 w-5 mr-2" />
                        Request a Quote
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <Card key={product.id} className="hover:shadow-lg transition-shadow flex flex-col">
                      <Link href={`/products/${product.id}`}>
                        <div className="relative h-48 overflow-hidden rounded-t-lg bg-muted">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                          />
                          {!product.inStock && (
                            <Badge className="absolute top-2 right-2 bg-destructive">
                              Out of Stock
                            </Badge>
                          )}
                          {product.priceType === "quote" && (
                            <Badge className="absolute top-2 left-2 bg-secondary">
                              RFQ Only
                            </Badge>
                          )}
                          {product.voltageLevel && (
                            <Badge className="absolute bottom-2 left-2 bg-primary/90 backdrop-blur-sm flex items-center gap-1">
                              <Zap className="h-3 w-3" />
                              {product.voltageLevel}
                            </Badge>
                          )}
                        </div>
                      </Link>
                      <CardHeader>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <Link href={`/products/${product.id}`}>
                              <CardTitle className="text-lg hover:text-primary transition-colors line-clamp-2">
                                {product.name}
                              </CardTitle>
                            </Link>
                            <CardDescription className="mt-1">
                              Code: {product.code}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline">{product.brand}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="flex-1 flex flex-col justify-end">
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {product.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <div>
                            {product.priceType === "fixed" ? (
                              <p className="text-2xl font-bold text-primary">
                                ${product.price.toLocaleString()}
                              </p>
                            ) : (
                              <p className="text-lg font-semibold text-muted-foreground">
                                Request Quote
                              </p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            {product.priceType === "fixed" && product.inStock ? (
                              <Button size="sm" asChild>
                                <Link href={`/products/${product.id}`}>
                                  <ShoppingCart className="h-4 w-4 mr-1" />
                                  Add
                                </Link>
                              </Button>
                            ) : (
                              <Button size="sm" variant="outline" asChild>
                                <Link href={`/request-quote?product=${product.id}`}>
                                  <FileText className="h-4 w-4 mr-1" />
                                  Quote
                                </Link>
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* RFQ CTA at Bottom */}
                <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                  <CardContent className="p-8 text-center">
                    <FileText className="h-12 w-12 text-primary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">
                      Didn't find what you're looking for?
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Submit a Request for Quotation and we'll get back to you with the best solution.
                    </p>
                    <Button size="lg" asChild>
                      <Link href="/request-quote">
                        <FileText className="h-5 w-5 mr-2" />
                        Request a Quote
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating Admin Button */}
      {!isPending && session?.user && (
        <Link href="/admin">
          <Button
            size="lg"
            className="fixed bottom-6 right-6 h-14 px-6 shadow-lg hover:shadow-xl transition-all z-50 gap-2"
          >
            <Settings className="h-5 w-5" />
            Manage Products
          </Button>
        </Link>
      )}
    </main>
  );
}