"use client";

import { Suspense } from "react";
import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue } from
"@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle } from
"@/components/ui/dialog";
import { FileText, Upload, CheckCircle, Building2, Phone, Mail, Calendar as CalendarIcon, Clock } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { toast } from "sonner";

function RequestQuoteForm() {
  const searchParams = useSearchParams();
  const productId = searchParams.get("product");
  const service = searchParams.get("service");
  const type = searchParams.get("type");

  const [formData, setFormData] = useState({
    companyName: "",
    contactPerson: "",
    email: "",
    phone: "",
    country: "",
    city: "",
    industry: "",
    productDescription: "",
    quantity: "",
    deliveryTimeline: "",
    additionalRequirements: ""
  });

  const [files, setFiles] = useState<File[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string>("");

  // Auto-populate product/service name when component mounts
  useEffect(() => {
    let autoDescription = "";

    if (service) {
      const serviceNames: Record<string, string> = {
        'installation': 'Installation Service',
        'amc': 'Annual Maintenance Contract',
        'calibration': 'Calibration Service',
        'commissioning': 'Testing & Commissioning Service'
      };
      autoDescription = serviceNames[service] || service;

      // Add type if present (meeting or site-visit)
      if (type === 'meeting') {
        autoDescription += ' - Schedule Meeting';
      } else if (type === 'site-visit') {
        autoDescription += ' - Site Visit Request';
      }
    } else if (productId) {
      autoDescription = `Product Inquiry - ID: ${productId}`;
    }

    if (autoDescription) {
      setFormData((prev) => ({ ...prev, productDescription: autoDescription }));
    }

    // Auto-open calendar for meeting/site-visit types
    if (type === 'meeting' || type === 'site-visit') {
      setShowCalendar(true);
    }
  }, [productId, service, type]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      console.log('Submitting form data:', formData);

      // Prepare submission data
      const submissionData = {
        ...formData,
        scheduledDate: selectedDate ? format(selectedDate, "PPP") : undefined,
        scheduledTime: selectedTime || undefined,
        requestType: type || undefined,
      };

      console.log('Full submission data:', submissionData);

      // Submit to API endpoint
      const response = await fetch('/api/quote', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(submissionData),
      });

      console.log('API response status:', response.status);

      const result = await response.json();
      console.log('API response data:', result);

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Failed to submit quote request');
      }

      toast.success("Quote request submitted successfully!", {
        description: "You will receive a confirmation email shortly.",
      });
      setSubmitted(true);

    } catch (error) {
      console.error('Submission error:', error);
      toast.error("Failed to submit quote request", {
        description: error instanceof Error ? error.message : "Please try again or contact us directly at belal.elansary@r-aletqan.com",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Available time slots
  const timeSlots = [
  "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM"];


  // Disable weekends and past dates
  const disabledDays = [
  { dayOfWeek: [5, 6] }, // Friday and Saturday (weekends in Saudi Arabia)
  { before: new Date() }];


  if (submitted) {
    return (
      <main className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-16">
          <Card className="max-w-2xl mx-auto text-center">
            <CardHeader>
              <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl">Quote Request Submitted!</CardTitle>
              <CardDescription>
                Thank you for your interest. We have received your {type === 'meeting' || type === 'site-visit' ? 'appointment' : 'quote'} request.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-6">
                Our team will review your requirements and get back to you within 24 hours{selectedDate && ` to confirm your appointment on ${format(selectedDate, "PPP")}${selectedTime ? ` at ${selectedTime}` : ''}`}.
                You will receive a confirmation email shortly at <strong>{formData.email}</strong>.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={() => {
                  setSubmitted(false);
                  setSelectedDate(undefined);
                  setSelectedTime("");
                }}>
                  Submit Another Request
                </Button>
                <Button variant="outline" asChild>
                  <a href="/">Return to Home</a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>);

  }

  return (
    <main className="min-h-screen bg-background">
      {/* Page Header */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <FileText className="h-12 w-12 mx-auto mb-4" />
            <h1 className="text-4xl font-bold mb-4">
              {type === 'meeting' ? 'Schedule a Meeting' : type === 'site-visit' ? 'Schedule Site Visit' : 'Request for Quote'}
            </h1>
            <p className="text-xl text-primary-foreground/90">
              {type === 'meeting' || type === 'site-visit' ?
              'Select your preferred date and time, and our team will confirm the appointment.' :
              'Get competitive pricing for your industrial automation needs. Fill out the form below and our team will respond within 24 hours.'}
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>
                  {type === 'meeting' || type === 'site-visit' ? 'Appointment Request Form' : 'Quote Request Form'}
                </CardTitle>
                <CardDescription>
                  Please provide detailed information to help us {type === 'meeting' || type === 'site-visit' ? 'schedule your appointment' : 'prepare an accurate quotation'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Calendar Section for meetings/site visits */}
                  {(type === 'meeting' || type === 'site-visit') &&
                  <>
                      <div>
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          <CalendarIcon className="h-5 w-5 text-primary" />
                          Select Date & Time
                        </h3>
                        <div className="space-y-4">
                          <Button
                          type="button"
                          variant="outline"
                          className="w-full justify-start text-left font-normal"
                          onClick={() => setShowCalendar(true)}>

                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                          </Button>
                          
                          {selectedDate &&
                        <div>
                              <Label htmlFor="timeSlot">Preferred Time Slot</Label>
                              <Select value={selectedTime} onValueChange={setSelectedTime}>
                                <SelectTrigger id="timeSlot">
                                  <SelectValue placeholder="Select time" />
                                </SelectTrigger>
                                <SelectContent>
                                  {timeSlots.map((time) =>
                              <SelectItem key={time} value={time}>
                                      <div className="flex items-center gap-2">
                                        <Clock className="h-4 w-4" />
                                        {time}
                                      </div>
                                    </SelectItem>
                              )}
                                </SelectContent>
                              </Select>
                            </div>
                        }
                        </div>
                      </div>
                      
                      <Separator />
                    </>
                  }

                  {/* Company Information */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-primary" />
                      Company Information
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="md:col-span-2">
                        <Label htmlFor="companyName">Company Name *</Label>
                        <Input
                          id="companyName"
                          name="companyName"
                          value={formData.companyName}
                          onChange={handleInputChange}
                          placeholder="Your company name"
                          required />

                      </div>
                      <div>
                        <Label htmlFor="contactPerson">Contact Person *</Label>
                        <Input
                          id="contactPerson"
                          name="contactPerson"
                          value={formData.contactPerson}
                          onChange={handleInputChange}
                          placeholder="Full name"
                          required />

                      </div>
                      <div>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="email@company.com"
                          required />

                      </div>
                      <div>
                        <Label htmlFor="phone">Phone Number *</Label>
                        <Input
                          id="phone"
                          name="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="+966 XX XXX XXXX"
                          required />

                      </div>
                      <div>
                        <Label htmlFor="country">Country *</Label>
                        <Select
                          value={formData.country}
                          onValueChange={(value) => handleSelectChange("country", value)}
                          required>

                          <SelectTrigger id="country">
                            <SelectValue placeholder="Select country" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="saudi-arabia">Saudi Arabia</SelectItem>
                            <SelectItem value="uae">United Arab Emirates</SelectItem>
                            <SelectItem value="kuwait">Kuwait</SelectItem>
                            <SelectItem value="qatar">Qatar</SelectItem>
                            <SelectItem value="bahrain">Bahrain</SelectItem>
                            <SelectItem value="oman">Oman</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="city">City *</Label>
                        <Input
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          placeholder="City"
                          required />

                      </div>
                      <div>
                        <Label htmlFor="industry">Industry Sector</Label>
                        <Select
                          value={formData.industry}
                          onValueChange={(value) => handleSelectChange("industry", value)}>

                          <SelectTrigger id="industry">
                            <SelectValue placeholder="Select industry" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="oil-gas">Oil & Gas</SelectItem>
                            <SelectItem value="manufacturing">Manufacturing</SelectItem>
                            <SelectItem value="water-treatment">Water Treatment</SelectItem>
                            <SelectItem value="power-energy">Power & Energy</SelectItem>
                            <SelectItem value="food-beverage">Food & Beverage</SelectItem>
                            <SelectItem value="pharmaceutical">Pharmaceutical</SelectItem>
                            <SelectItem value="infrastructure">Infrastructure</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Product/Service Requirements */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Product/Service Requirements</h3>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="productDescription">Product/Service Description *</Label>
                        <Textarea
                          id="productDescription"
                          name="productDescription"
                          value={formData.productDescription}
                          onChange={handleInputChange}
                          placeholder="Describe the products or services you need (brands, models, specifications, etc.)"
                          rows={4}
                          required />

                        <p className="text-xs text-muted-foreground mt-1">
                          Please include product codes, brands, or specifications if known
                        </p>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="quantity">Quantity</Label>
                          <Input
                            id="quantity"
                            name="quantity"
                            value={formData.quantity}
                            onChange={handleInputChange}
                            placeholder="e.g., 5 units, 100 pieces" />

                        </div>
                        <div>
                          <Label htmlFor="deliveryTimeline">Delivery Timeline</Label>
                          <Select
                            value={formData.deliveryTimeline}
                            onValueChange={(value) => handleSelectChange("deliveryTimeline", value)}>

                            <SelectTrigger id="deliveryTimeline">
                              <SelectValue placeholder="Select timeline" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="urgent">Urgent (Within 1 week)</SelectItem>
                              <SelectItem value="standard">Standard (2-4 weeks)</SelectItem>
                              <SelectItem value="flexible">Flexible (1-2 months)</SelectItem>
                              <SelectItem value="project">Project-based</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="additionalRequirements">Additional Requirements</Label>
                        <Textarea
                          id="additionalRequirements"
                          name="additionalRequirements"
                          value={formData.additionalRequirements}
                          onChange={handleInputChange}
                          placeholder="Installation services, training, warranty requirements, payment terms, etc."
                          rows={3} />

                        <p className="text-xs text-muted-foreground mt-1">
                          If left blank, the product/service name will be used as the request title
                        </p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* File Upload */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Upload className="h-5 w-5 text-primary" />
                      Upload Documents (Optional)
                    </h3>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center hover:border-primary transition-colors">
                      <Input
                        id="file-upload"
                        type="file"
                        multiple
                        onChange={handleFileChange}
                        className="hidden"
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.png" />

                      <Label htmlFor="file-upload" className="cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm font-medium mb-1">
                          Click to upload or drag and drop
                        </p>
                        <p className="text-xs text-muted-foreground">
                          BOQ, specifications, drawings, or reference documents (Max 10MB)
                        </p>
                      </Label>
                      {files.length > 0 &&
                      <div className="mt-4 space-y-2">
                          {files.map((file, index) =>
                        <div key={index} className="text-sm text-left bg-muted p-2 rounded">
                              {file.name} ({(file.size / 1024).toFixed(2)} KB)
                            </div>
                        )}
                        </div>
                      }
                    </div>
                  </div>

                  <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <span className="animate-spin mr-2">⏳</span>
                        Sending...
                      </>
                    ) : (
                      type === 'meeting' || type === 'site-visit' ? 'Schedule Appointment' : 'Submit Quote Request'
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Why Choose Us */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {type === 'meeting' || type === 'site-visit' ? 'What to Expect' : 'Why Request a Quote?'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Competitive pricing with volume discounts</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Expert technical consultation included</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Flexible payment terms available</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Fast response within 24 hours</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>Complete project solutions available</span>
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Need Help?</CardTitle>
                <CardDescription>Our team is ready to assist you</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div className="flex items-start gap-3">
                  <Phone className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Call Us</p>
                    <a href="tel:+966123456789" className="text-muted-foreground hover:text-primary">
                      +966 12 345 6789
                    </a>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Mail className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold">Email Us</p>
                    <a href="mailto:sales@riyadhaletqan.com" className="text-muted-foreground hover:text-primary">
                      sales@riyadhaletqan.com
                    </a>
                  </div>
                </div>
                <Separator />
                <p className="text-muted-foreground">
                  <strong>Business Hours:</strong><br />
                  Sunday - Thursday: 8:00 AM - 5:00 PM<br />
                  Saturday: 9:00 AM - 1:00 PM
                </p>
              </CardContent>
            </Card>

            {/* Services */}
            <Card className="bg-primary text-primary-foreground">
              <CardHeader>
                <CardTitle className="text-lg">Additional Services</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <p>• Installation & Commissioning</p>
                <p>• Annual Maintenance Contracts</p>
                <p>• Technical Training</p>
                <p>• Turnkey Project Solutions</p>
                <Button variant="secondary" className="w-full mt-4" asChild>
                  <a href="/services">View All Services</a>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Calendar Dialog */}
      <Dialog open={showCalendar} onOpenChange={setShowCalendar}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Select a Date</DialogTitle>
            <DialogDescription>
              Choose your preferred date for the {type === 'site-visit' ? 'site visit' : 'meeting'}. 
              Business hours: Sunday-Thursday (8AM-5PM), Saturday (9AM-1PM)
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center py-4">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => {
                setSelectedDate(date);
                setShowCalendar(false);
              }}
              disabled={disabledDays}
              initialFocus />

          </div>
        </DialogContent>
      </Dialog>
    </main>);

}

export default function RequestQuotePage() {
  return (
    <Suspense fallback={
    <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading form...</p>
        </div>
      </div>
    }>
      <RequestQuoteForm />
    </Suspense>);

}