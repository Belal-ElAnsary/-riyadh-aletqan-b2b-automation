"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RotateCcw, CheckCircle, XCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function ReturnsPage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <RotateCcw className="h-12 w-12 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Returns & Refunds
            </h1>
            <p className="text-xl text-primary-foreground/90">
              Our commitment to your satisfaction with clear return and refund policies
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Return Policy Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Return Policy Overview</CardTitle>
              <CardDescription>Understanding your return options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <Clock className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h3 className="font-semibold mb-1">14-Day Window</h3>
                  <p className="text-xs text-muted-foreground">Return within 14 days of delivery</p>
                </div>
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <CheckCircle className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h3 className="font-semibold mb-1">Original Condition</h3>
                  <p className="text-xs text-muted-foreground">Unused and in original packaging</p>
                </div>
                <div className="text-center p-4 bg-muted/30 rounded-lg">
                  <RotateCcw className="h-8 w-8 text-primary mx-auto mb-2" />
                  <h3 className="font-semibold mb-1">Full Refund</h3>
                  <p className="text-xs text-muted-foreground">100% refund for eligible returns</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Eligible Returns */}
          <Card>
            <CardHeader>
              <CardTitle>Eligible for Return</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Defective Products:</strong> Items that arrive damaged or defective
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Wrong Items:</strong> If you received incorrect products
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Unused Products:</strong> Products in original packaging, unused with all accessories
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Warranty Claims:</strong> Products covered under manufacturer warranty
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Non-Returnable Items */}
          <Card>
            <CardHeader>
              <CardTitle>Non-Returnable Items</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Custom Orders:</strong> Items made to order or customized products
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Installed Products:</strong> Equipment that has been installed or commissioned
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Software & Licenses:</strong> Digital products and software licenses
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                  <div>
                    <strong>Final Sale Items:</strong> Products marked as clearance or final sale
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Return Process */}
          <Card>
            <CardHeader>
              <CardTitle>How to Return</CardTitle>
              <CardDescription>Simple steps to process your return</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold flex-shrink-0">
                    1
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Contact Us</h3>
                    <p className="text-sm text-muted-foreground">
                      Email returns@riyadhaletqan.com or call +966 12 345 6789 with your order number and reason for return
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold flex-shrink-0">
                    2
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Get Authorization</h3>
                    <p className="text-sm text-muted-foreground">
                      Receive a Return Authorization Number (RAN) and return instructions
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold flex-shrink-0">
                    3
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Ship the Item</h3>
                    <p className="text-sm text-muted-foreground">
                      Package the item securely with all accessories and ship to the provided address
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold flex-shrink-0">
                    4
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Receive Refund</h3>
                    <p className="text-sm text-muted-foreground">
                      Refund processed within 5-7 business days after receiving and inspecting the return
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Refund Policy */}
          <Card>
            <CardHeader>
              <CardTitle>Refund Policy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div>
                <h3 className="font-semibold mb-2">Refund Methods</h3>
                <p className="text-muted-foreground">
                  Refunds are issued to the original payment method used for the purchase. Bank transfers or store credit are available upon request.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Processing Time</h3>
                <p className="text-muted-foreground">
                  Once we receive and inspect your return, refunds are processed within 5-7 business days. Please allow additional time for your bank to process the refund.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Partial Refunds</h3>
                <p className="text-muted-foreground">
                  Partial refunds may be granted for items that show signs of use, missing parts, or damaged packaging not caused during shipping.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Return Shipping Costs</h3>
                <p className="text-muted-foreground">
                  Return shipping is free for defective or incorrect items. For other returns, customers are responsible for return shipping costs unless otherwise agreed.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact CTA */}
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="pt-6 text-center">
              <h3 className="text-xl font-semibold mb-2">Need Help with a Return?</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Our customer service team is here to assist you with any return or refund questions
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button asChild>
                  <Link href="/request-quote">Contact Support</Link>
                </Button>
                <Button variant="outline">
                  Call +966 12 345 6789
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
