"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  CheckCircle, 
  Clock, 
  Wrench, 
  Phone,
  FileText,
  TrendingUp,
  Users,
  Calendar
} from "lucide-react";

export default function AMCPage() {
  const benefits = [
    {
      icon: Shield,
      title: "Extended Equipment Life",
      description: "Regular maintenance prevents breakdowns and extends the operational life of your equipment"
    },
    {
      icon: TrendingUp,
      title: "Reduced Downtime",
      description: "Proactive maintenance minimizes unexpected failures and production interruptions"
    },
    {
      icon: Wrench,
      title: "Priority Support",
      description: "AMC customers receive priority response for service calls and technical support"
    },
    {
      icon: Users,
      title: "Expert Technicians",
      description: "Certified engineers with extensive experience in industrial automation systems"
    }
  ];

  const plans = [
    {
      name: "Basic AMC",
      price: "Starting from $2,500/year",
      features: [
        "Quarterly preventive maintenance visits",
        "Basic troubleshooting and repairs",
        "Equipment health reports",
        "Email and phone support",
        "10% discount on spare parts",
        "Response time: 48 hours"
      ],
      recommended: false
    },
    {
      name: "Standard AMC",
      price: "Starting from $4,800/year",
      features: [
        "Monthly preventive maintenance visits",
        "Priority troubleshooting and repairs",
        "Comprehensive health monitoring",
        "24/7 phone support",
        "20% discount on spare parts",
        "Response time: 24 hours",
        "Annual performance audit",
        "Firmware updates included"
      ],
      recommended: true
    },
    {
      name: "Premium AMC",
      price: "Custom pricing",
      features: [
        "Weekly preventive maintenance",
        "Dedicated engineer on-site",
        "Real-time monitoring systems",
        "24/7 emergency support",
        "30% discount on spare parts",
        "Response time: 4 hours",
        "Quarterly training sessions",
        "Complete documentation",
        "Backup equipment provided"
      ],
      recommended: false
    }
  ];

  const coverageAreas = [
    "Variable Frequency Drives (VFDs)",
    "Programmable Logic Controllers (PLCs)",
    "Human Machine Interfaces (HMIs)",
    "Servo Motors & Systems",
    "Safety Systems & Relays",
    "Power Distribution Equipment",
    "Industrial Sensors & Instruments",
    "Control Panels & Switchgear"
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground">
              AMC Services
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Annual Maintenance Contracts
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8">
              Keep your industrial automation systems running at peak performance with our comprehensive maintenance plans
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                <Link href="/request-quote?service=amc">
                  Request AMC Quote
                  <FileText className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
                <Link href="/request-quote?service=amc&type=site-visit">
                  <Calendar className="mr-2 h-5 w-5" />
                  Schedule Site Visit
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our AMC Services?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Protect your investment and ensure continuous operation with professional maintenance
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <benefit.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Plans Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our AMC Plans</h2>
            <p className="text-muted-foreground">
              Choose the maintenance plan that best fits your operational needs
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan, index) => (
              <Card key={index} className={`flex flex-col ${plan.recommended ? 'border-primary border-2 shadow-lg' : ''}`}>
                <CardHeader>
                  {plan.recommended && (
                    <Badge className="mb-2 w-fit bg-primary">Most Popular</Badge>
                  )}
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription className="text-xl font-bold text-foreground mt-2">
                    {plan.price}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <ul className="space-y-3">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardContent className="pt-0">
                  <Button className="w-full" variant={plan.recommended ? "default" : "outline"} asChild>
                    <Link href={`/request-quote?service=amc&plan=${plan.name.toLowerCase().replace(' ', '-')}`}>
                      Get Started
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Coverage Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Equipment Coverage</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {coverageAreas.map((area, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                      <Wrench className="h-5 w-5 text-primary flex-shrink-0" />
                      <span className="font-medium">{area}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">How Our AMC Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-2">
                    1
                  </div>
                  <CardTitle className="text-lg">Initial Assessment</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    We evaluate your equipment and recommend the best plan
                  </p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-2">
                    2
                  </div>
                  <CardTitle className="text-lg">Contract Setup</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Sign the agreement and schedule maintenance visits
                  </p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-2">
                    3
                  </div>
                  <CardTitle className="text-lg">Regular Service</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Our technicians perform scheduled maintenance visits
                  </p>
                </CardContent>
              </Card>
              <Card className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mb-2">
                    4
                  </div>
                  <CardTitle className="text-lg">Reporting</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Receive detailed reports and recommendations
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
            <CardContent className="text-center py-12">
              <h2 className="text-3xl font-bold mb-4">
                Ready to Protect Your Equipment?
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
                Get a customized AMC quote or schedule a site visit for equipment assessment
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                  <Link href="/request-quote?service=amc">
                    Request AMC Quote
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
                  <Link href="/request-quote?service=amc&type=site-visit">
                    <Calendar className="mr-2 h-5 w-5" />
                    Schedule Site Visit
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}