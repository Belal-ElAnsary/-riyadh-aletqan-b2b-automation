"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Gauge, 
  CheckCircle, 
  FileText,
  Award,
  Clock,
  Target
} from "lucide-react";

export default function CalibrationPage() {
  const equipment = [
    "Pressure Transmitters & Sensors",
    "Temperature Sensors & Controllers",
    "Flow Meters & Indicators",
    "Level Transmitters",
    "Analytical Instruments",
    "Control Valves & Positioners",
    "Load Cells & Weighing Systems",
    "Measurement & Test Equipment"
  ];

  const benefits = [
    {
      icon: Target,
      title: "Accuracy Assurance",
      description: "Ensure your instruments meet required accuracy specifications and tolerances"
    },
    {
      icon: Award,
      title: "Compliance",
      description: "Meet regulatory requirements and industry standards (ISO, ANSI, NIST)"
    },
    {
      icon: Clock,
      title: "Prevent Downtime",
      description: "Scheduled calibration prevents unexpected failures and production losses"
    }
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground">
              Calibration Services
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Calibration & Verification Services
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8">
              Precision calibration services for industrial instruments and measurement devices with ISO-traceable certificates
            </p>
            <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
              <Link href="/request-quote?service=calibration">
                Request Calibration Quote
                <FileText className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <benefit.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Equipment Coverage */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Equipment We Calibrate</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {equipment.map((item, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                      <Gauge className="h-5 w-5 text-primary flex-shrink-0" />
                      <span className="font-medium">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Our Calibration Process</h2>
            <div className="space-y-6">
              {[
                { title: "Pre-Calibration Assessment", desc: "Initial testing and documentation of current instrument status" },
                { title: "Calibration Procedure", desc: "Precision calibration using traceable reference standards" },
                { title: "Adjustment & Testing", desc: "Fine-tuning and verification to meet specifications" },
                { title: "Documentation", desc: "Issue calibration certificate with full traceability" }
              ].map((step, index) => (
                <Card key={index}>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold flex-shrink-0">
                        {index + 1}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                        <p className="text-muted-foreground">{step.desc}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground max-w-3xl mx-auto">
            <CardContent className="text-center py-12">
              <h2 className="text-3xl font-bold mb-4">
                Schedule Your Calibration Service
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90">
                Ensure accuracy and compliance with our professional calibration services
              </p>
              <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                <Link href="/request-quote?service=calibration">
                  Request Quote
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}
