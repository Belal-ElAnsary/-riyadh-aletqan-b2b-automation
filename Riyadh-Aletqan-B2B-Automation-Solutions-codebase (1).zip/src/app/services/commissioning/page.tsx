"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  PlayCircle, 
  CheckCircle, 
  FileText,
  Settings,
  TestTube,
  FileCheck
} from "lucide-react";

export default function CommissioningPage() {
  const services = [
    {
      icon: Settings,
      title: "System Configuration",
      description: "Complete system setup, programming, and parameter configuration"
    },
    {
      icon: TestTube,
      title: "Functional Testing",
      description: "Comprehensive testing of all system components and functions"
    },
    {
      icon: PlayCircle,
      title: "Performance Verification",
      description: "Validation that system meets all performance requirements"
    },
    {
      icon: FileCheck,
      title: "Documentation",
      description: "Complete commissioning reports and as-built documentation"
    }
  ];

  const phases = [
    {
      phase: "Pre-Commissioning",
      activities: [
        "Visual inspection of installation",
        "Wiring and connection verification",
        "Power supply checks",
        "Equipment inventory check"
      ]
    },
    {
      phase: "Commissioning",
      activities: [
        "System programming and configuration",
        "Individual component testing",
        "Integrated system testing",
        "Safety system verification"
      ]
    },
    {
      phase: "Performance Testing",
      activities: [
        "Load testing and optimization",
        "Performance benchmarking",
        "Fine-tuning and adjustments",
        "Final acceptance testing"
      ]
    },
    {
      phase: "Handover",
      activities: [
        "Operator training",
        "Documentation delivery",
        "System demonstration",
        "Support transition"
      ]
    }
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground">
              Testing & Commissioning
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Testing & Commissioning Services
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8">
              Professional commissioning and testing services ensuring your automation systems are ready for production
            </p>
            <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
              <Link href="/request-quote?service=commissioning">
                Request Commissioning Quote
                <FileText className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Commissioning Services</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Comprehensive testing and commissioning for all automation systems
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <service.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Phases */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">Commissioning Phases</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {phases.map((phase, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle>{phase.phase}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {phase.activities.map((activity, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-sm">{activity}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground max-w-3xl mx-auto">
            <CardContent className="text-center py-12">
              <h2 className="text-3xl font-bold mb-4">
                Ready to Commission Your System?
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90">
                Get expert commissioning services with guaranteed results
              </p>
              <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                <Link href="/request-quote?service=commissioning">
                  Request Quote
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}
