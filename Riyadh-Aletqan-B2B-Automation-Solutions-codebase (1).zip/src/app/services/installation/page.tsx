"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Wrench, 
  CheckCircle, 
  Award, 
  Users,
  FileText,
  Settings,
  Zap,
  Shield,
  Calendar
} from "lucide-react";

export default function InstallationPage() {
  const services = [
    {
      icon: Zap,
      title: "Drives & Motor Installation",
      description: "Professional installation of VFDs, servo drives, and motor control systems with proper wiring and commissioning"
    },
    {
      icon: Settings,
      title: "PLC & Control System Setup",
      description: "Complete installation and configuration of PLCs, SCADA systems, and automation controllers"
    },
    {
      icon: Shield,
      title: "Safety System Integration",
      description: "Installation of safety relays, emergency stops, light curtains, and safety PLCs"
    },
    {
      icon: Wrench,
      title: "Panel Building & Wiring",
      description: "Custom control panel fabrication, wiring, and integration according to specifications"
    }
  ];

  const process = [
    {
      step: "1",
      title: "Site Survey",
      description: "Our engineers visit your facility to assess installation requirements and site conditions"
    },
    {
      step: "2",
      title: "Planning & Design",
      description: "Develop detailed installation plan including wiring diagrams and equipment layout"
    },
    {
      step: "3",
      title: "Installation",
      description: "Professional installation by certified technicians following industry best practices"
    },
    {
      step: "4",
      title: "Testing & Commissioning",
      description: "Comprehensive testing, calibration, and system commissioning before handover"
    },
    {
      step: "5",
      title: "Training & Documentation",
      description: "Operator training and complete documentation package delivery"
    }
  ];

  const features = [
    "Certified and experienced installation engineers",
    "Compliance with international safety standards",
    "Complete project documentation",
    "Post-installation support and warranty",
    "Minimal disruption to operations",
    "Quality assurance at every step"
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground">
              Installation Services
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Professional Installation & Commissioning
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8">
              Expert installation services for industrial automation equipment with guaranteed quality and compliance
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                <Link href="/request-quote?service=installation">
                  Request Installation Quote
                  <FileText className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
                <Link href="/request-quote?service=installation&type=meeting">
                  <Calendar className="mr-2 h-5 w-5" />
                  Schedule Meeting
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Installation Services</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Comprehensive installation solutions for all types of industrial automation equipment
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <service.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-xl">{service.title}</CardTitle>
                      <CardDescription className="mt-2">{service.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Installation Process</h2>
            <p className="text-muted-foreground">
              A systematic approach ensuring successful project delivery
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {process.map((item, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold flex-shrink-0">
                        {item.step}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-center">Why Choose Our Installation Services?</h2>
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <Award className="h-12 w-12 text-primary mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4">Certified Professionals</h2>
            <p className="text-muted-foreground mb-8">
              Our installation team holds certifications from major manufacturers including Siemens, Schneider Electric, ABB, and Rockwell Automation. We follow international standards and safety protocols to ensure the highest quality installation.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="bg-background p-6 rounded-lg">
                <p className="font-semibold">ISO 9001:2015</p>
              </div>
              <div className="bg-background p-6 rounded-lg">
                <p className="font-semibold">Siemens Certified</p>
              </div>
              <div className="bg-background p-6 rounded-lg">
                <p className="font-semibold">Schneider Partner</p>
              </div>
              <div className="bg-background p-6 rounded-lg">
                <p className="font-semibold">ABB Authorized</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
            <CardContent className="text-center py-12">
              <h2 className="text-3xl font-bold mb-4">
                Need Professional Installation?
              </h2>
              <p className="text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
                Get a detailed quote for your installation project or schedule a meeting with our team
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                  <Link href="/request-quote?service=installation">
                    Request Installation Quote
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
                  <Link href="/request-quote?service=installation&type=meeting">
                    <Calendar className="mr-2 h-5 w-5" />
                    Schedule Meeting
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}