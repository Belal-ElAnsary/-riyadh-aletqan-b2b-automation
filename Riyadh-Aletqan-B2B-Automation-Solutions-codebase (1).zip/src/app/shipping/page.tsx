"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Truck, Package, MapPin, Clock, CheckCircle } from "lucide-react";

export default function ShippingPage() {
  const shippingOptions = [
    {
      name: "Standard Delivery",
      duration: "3-5 business days",
      coverage: "Riyadh and major cities",
      cost: "Free for orders above SAR 5,000"
    },
    {
      name: "Express Delivery",
      duration: "1-2 business days",
      coverage: "Riyadh metropolitan area",
      cost: "Additional charges apply"
    },
    {
      name: "GCC Shipping",
      duration: "5-10 business days",
      coverage: "UAE, Kuwait, Qatar, Bahrain, Oman",
      cost: "Calculated based on weight and destination"
    }
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Truck className="h-12 w-12 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Shipping & Delivery
            </h1>
            <p className="text-xl text-primary-foreground/90">
              Fast and reliable delivery across Saudi Arabia and the GCC region
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Shipping Options */}
          <section>
            <h2 className="text-3xl font-bold mb-6">Delivery Options</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {shippingOptions.map((option, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Package className="h-5 w-5 text-primary" />
                      {option.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="flex items-start gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                      <span>{option.duration}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                      <span>{option.coverage}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                      <span>{option.cost}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* General Information */}
          <Card>
            <CardHeader>
              <CardTitle>General Shipping Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Order Processing</h3>
                <p className="text-sm text-muted-foreground">
                  Orders are processed within 1-2 business days. You will receive a confirmation email once your order has been shipped with tracking information.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Tracking Your Order</h3>
                <p className="text-sm text-muted-foreground">
                  Once shipped, you'll receive a tracking number via email to monitor your delivery status in real-time.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Delivery Confirmation</h3>
                <p className="text-sm text-muted-foreground">
                  A signature may be required upon delivery for high-value items. Please ensure someone is available to receive the package.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Special Handling</h3>
                <p className="text-sm text-muted-foreground">
                  Heavy or oversized items may require special delivery arrangements. Our team will contact you to coordinate delivery.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* International Shipping */}
          <Card>
            <CardHeader>
              <CardTitle>GCC & International Shipping</CardTitle>
              <CardDescription>Delivering across the Gulf region</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <p>
                We ship to all GCC countries including UAE, Kuwait, Qatar, Bahrain, and Oman. Shipping costs and delivery times vary by destination and package weight.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>Customs clearance assistance included</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>All necessary documentation provided</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <span>Insurance coverage available for high-value shipments</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card className="bg-muted/30">
            <CardContent className="pt-6">
              <h3 className="font-semibold mb-2">Need Help with Delivery?</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Contact our customer service team for any shipping-related queries or special delivery requirements.
              </p>
              <p className="text-sm">
                <strong>Email:</strong> shipping@riyadhaletqan.com<br />
                <strong>Phone:</strong> +966 12 345 6789
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
