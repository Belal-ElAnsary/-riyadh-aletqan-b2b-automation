"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <FileText className="h-12 w-12 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Terms & Conditions
            </h1>
            <p className="text-xl text-primary-foreground/90">
              Please read these terms carefully before using our services
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>1. Agreement to Terms</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                By accessing and using the Riyadh Aletqan Company website and services, you agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our services.
              </p>
              <p>
                These terms apply to all visitors, users, and customers who access or use our service.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>2. Use of Services</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                Our services are intended for business-to-business (B2B) transactions. You represent that you are of legal age and have the authority to enter into binding contracts.
              </p>
              <p>
                You agree to use our services only for lawful purposes and in accordance with these Terms.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>3. Product Information</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                We strive to provide accurate product descriptions, specifications, and pricing. However, we do not warrant that product descriptions or other content is accurate, complete, reliable, or error-free.
              </p>
              <p>
                All products are subject to availability. We reserve the right to discontinue any product at any time.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>4. Pricing and Payment</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                All prices are in Saudi Riyals (SAR) and are subject to change without notice. Prices exclude VAT and shipping charges unless otherwise stated.
              </p>
              <p>
                Payment terms for corporate accounts are subject to credit approval. Late payments may incur additional charges.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>5. Orders and Contracts</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                Your order constitutes an offer to purchase products or services. We reserve the right to accept or decline your order at our discretion.
              </p>
              <p>
                Order confirmations are sent via email and constitute a binding contract once accepted.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>6. Intellectual Property</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                All content on this website, including text, graphics, logos, images, and software, is the property of Riyadh Aletqan Company or its licensors and is protected by copyright and other intellectual property laws.
              </p>
              <p>
                You may not reproduce, distribute, modify, or create derivative works without our express written permission.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>7. Warranties and Disclaimers</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                Products are covered by manufacturer warranties as specified in product documentation. We act as a distributor and warranty claims are subject to manufacturer terms.
              </p>
              <p>
                Our services are provided "as is" without warranties of any kind, either express or implied, except as required by law.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>8. Limitation of Liability</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                To the maximum extent permitted by law, Riyadh Aletqan Company shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of our services.
              </p>
              <p>
                Our total liability shall not exceed the amount paid by you for the products or services in question.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>9. Governing Law</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                These Terms shall be governed by and construed in accordance with the laws of the Kingdom of Saudi Arabia.
              </p>
              <p>
                Any disputes arising from these Terms shall be subject to the exclusive jurisdiction of the courts of Riyadh, Saudi Arabia.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>10. Changes to Terms</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-3 text-muted-foreground">
              <p>
                We reserve the right to modify these Terms at any time. Changes will be effective immediately upon posting to the website.
              </p>
              <p>
                Your continued use of our services after changes constitutes acceptance of the modified Terms.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-muted/30">
            <CardContent className="pt-6 text-sm">
              <p className="font-semibold mb-2">Contact Information</p>
              <p className="text-muted-foreground">
                If you have any questions about these Terms and Conditions, please contact us at:<br />
                <strong>Email:</strong> legal@riyadhaletqan.com<br />
                <strong>Phone:</strong> +966 12 345 6789<br />
                <strong>Address:</strong> King Fahd Road, Riyadh, Saudi Arabia
              </p>
              <p className="text-xs text-muted-foreground mt-4">
                Last Updated: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
