"use client";

import Link from "next/link";
import * as React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { 
  Building2, 
  CheckCircle, 
  FileText,
  Lightbulb,
  Package,
  Settings,
  PlayCircle,
  Headphones,
  Target,
  Users,
  Clock,
  Award
} from "lucide-react";

export default function TurnkeyProjectsPage() {
  // Autoplay plugins for carousels
  const contractorsAutoplay = React.useRef(
    Autoplay({ delay: 3000, stopOnInteraction: false })
  );
  const clientsAutoplay = React.useRef(
    Autoplay({ delay: 3000, stopOnInteraction: false })
  );

  const capabilities = [
    {
      icon: Lightbulb,
      title: "Design & Engineering",
      description: "Complete system design with detailed engineering drawings and specifications"
    },
    {
      icon: Package,
      title: "Procurement",
      description: "Sourcing of all equipment from authorized distributors with quality assurance"
    },
    {
      icon: Settings,
      title: "Installation",
      description: "Professional installation by certified technicians following best practices"
    },
    {
      icon: PlayCircle,
      title: "Commissioning",
      description: "System testing, optimization, and commissioning for production readiness"
    },
    {
      icon: Users,
      title: "Training",
      description: "Comprehensive operator and maintenance training programs"
    },
    {
      icon: Headphones,
      title: "Support",
      description: "Post-project support and maintenance services to ensure long-term success"
    }
  ];

  const industries = [
    {
      name: "Oil & Gas",
      projects: "Pipeline automation, SCADA systems, safety instrumented systems"
    },
    {
      name: "Water Treatment",
      projects: "Process control, monitoring systems, pump control automation"
    },
    {
      name: "Manufacturing",
      projects: "Production line automation, quality control systems, material handling"
    },
    {
      name: "Power & Energy",
      projects: "Substation automation, power management systems, renewable energy control"
    },
    {
      name: "Food & Beverage",
      projects: "Batch control, packaging automation, cold storage management"
    },
    {
      name: "Infrastructure",
      projects: "Building automation, facility management systems, access control"
    }
  ];

  const whyChooseUs = [
    {
      icon: Target,
      title: "Single Point of Contact",
      description: "One partner for the entire project lifecycle from design to support"
    },
    {
      icon: Clock,
      title: "On-Time Delivery",
      description: "Proven track record of delivering projects on schedule and within budget"
    },
    {
      icon: Award,
      title: "Quality Assurance",
      description: "ISO-certified processes ensuring the highest quality standards"
    },
    {
      icon: Users,
      title: "Expert Team",
      description: "Multidisciplinary team with deep industry knowledge and experience"
    }
  ];

  const projectSteps = [
    {
      step: "1",
      title: "Consultation & Assessment",
      description: "Understanding your requirements, site conditions, and project objectives"
    },
    {
      step: "2",
      title: "Proposal & Design",
      description: "Detailed technical proposal with system architecture and project plan"
    },
    {
      step: "3",
      title: "Engineering & Procurement",
      description: "Detailed engineering, equipment procurement, and panel fabrication"
    },
    {
      step: "4",
      title: "Installation & Integration",
      description: "On-site installation, wiring, and system integration"
    },
    {
      step: "5",
      title: "Testing & Commissioning",
      description: "Comprehensive testing, optimization, and system commissioning"
    },
    {
      step: "6",
      title: "Training & Handover",
      description: "Training programs and complete documentation handover"
    }
  ];

  const contractors = [
    { name: "Binladin Group", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Nesma & Partners", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Rockwell", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Saudi Aramco", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "SABIC", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Bechtel", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Fluor Corporation", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Petrofac", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
  ];

  const endUserClients = [
    { name: "Yamama Cement", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Saudi Cement", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Arabian Cement", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Almarai", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "SPIMACO", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Saudi Steel", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Ma'aden", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
    { name: "Savola Group", logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=200&h=100&fit=crop" },
  ];

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground">
              Turnkey Solutions
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Complete Turnkey Project Solutions
            </h1>
            <p className="text-xl text-primary-foreground/90 mb-8">
              From concept to commissioning - we deliver end-to-end industrial automation projects as your trusted local partner in Saudi Arabia and the GCC
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
                <Link href="/request-quote?service=turnkey">
                  Start Your Project
                  <FileText className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                View Case Studies
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Complete Project Lifecycle Management</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We handle every aspect of your automation project, ensuring seamless execution and optimal results
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {capabilities.map((capability, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <capability.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{capability.title}</CardTitle>
                  <CardDescription>{capability.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Industries We Serve</h2>
            <p className="text-muted-foreground">
              Specialized turnkey solutions tailored for diverse industrial sectors
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {industries.map((industry, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-primary" />
                    {industry.name}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{industry.projects}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Partner With Us?</h2>
            <p className="text-muted-foreground">
              Your trusted local partner for industrial automation projects
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyChooseUs.map((item, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <item.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Project Process */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Project Delivery Process</h2>
            <p className="text-muted-foreground">
              A proven methodology ensuring successful project outcomes
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {projectSteps.map((item, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold flex-shrink-0">
                        {item.step}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Partners Section - Contractors & End-User Clients */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Partners</h2>
            <p className="text-lg text-muted-foreground">
              Trusted by leading contractors and major industrial clients across Saudi Arabia
            </p>
          </div>

          {/* Contractors Carousel */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold mb-6 text-center">Contractors</h3>
            <p className="text-center text-muted-foreground mb-8">
              Major EPC and industrial contractors we work with
            </p>
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              plugins={[contractorsAutoplay.current]}
              className="w-full max-w-6xl mx-auto"
            >
              <CarouselContent>
                {contractors.map((contractor, index) => (
                  <CarouselItem key={index} className="md:basis-1/3 lg:basis-1/4">
                    <div className="p-2">
                      <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow h-28 flex items-center justify-center border-2 border-border">
                        <span className="text-base font-semibold text-gray-700 text-center">{contractor.name}</span>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </div>

          {/* End-User Clients Carousel */}
          <div>
            <h3 className="text-2xl font-bold mb-6 text-center">End-User Clients</h3>
            <p className="text-center text-muted-foreground mb-8">
              Leading industrial enterprises in cement, manufacturing, and more
            </p>
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              plugins={[clientsAutoplay.current]}
              className="w-full max-w-6xl mx-auto"
            >
              <CarouselContent>
                {endUserClients.map((client, index) => (
                  <CarouselItem key={index} className="md:basis-1/3 lg:basis-1/4">
                    <div className="p-2">
                      <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow h-28 flex items-center justify-center border-2 border-border">
                        <span className="text-base font-semibold text-gray-700 text-center">{client.name}</span>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Recent Projects</h2>
            <p className="text-muted-foreground">
              Successfully delivered turnkey automation solutions
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Petrochemical Plant Automation",
                client: "Major Oil & Gas Company",
                scope: "Complete DCS implementation, 500+ I/O points",
                duration: "8 months"
              },
              {
                title: "Water Treatment Facility",
                client: "Municipal Water Authority",
                scope: "SCADA system, PLC networks, instrumentation",
                duration: "6 months"
              },
              {
                title: "Manufacturing Line Upgrade",
                client: "Food Processing Company",
                scope: "Production line automation, HMI systems",
                duration: "4 months"
              }
            ].map((project, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{project.title}</CardTitle>
                  <CardDescription>{project.client}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                    <span><strong>Scope:</strong> {project.scope}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <Clock className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                    <span><strong>Duration:</strong> {project.duration}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Your Turnkey Project?
          </h2>
          <p className="text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
            Let's discuss how we can deliver your complete automation solution from design to commissioning
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-secondary text-secondary-foreground hover:bg-secondary/90" asChild>
              <Link href="/request-quote?service=turnkey">
                Request Project Consultation
                <FileText className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary" asChild>
              <Link href="/request-quote?service=turnkey&type=meeting">
                Schedule a Meeting
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  );
}