"use client";

import Link from "next/link";
import { Phone, Mail, MapPin, Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-muted/50 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="text-primary-foreground px-4 py-2 rounded-md font-bold text-xl !bg-[url(https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763628677184-eg3os69t5hq.webp)] !bg-cover !bg-center !whitespace-pre-line !w-[39px] !h-full">

              </div>
              <div>
                <div className="font-bold text-lg">Riyadh Aletqan</div>
                <div className="text-xs text-muted-foreground">Industrial Automation Solutions</div>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Your trusted partner for industrial automation and electrical solutions in Saudi Arabia and the GCC. 
              We provide world-class products and services from leading brands.
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-primary flex-shrink-0" />
                <span className="text-muted-foreground">King Fahd Road, Riyadh, Saudi Arabia</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary flex-shrink-0" />
                <a href="tel:+966123456789" className="text-muted-foreground hover:text-primary">
                  +966 12 345 6789
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                <a href="mailto:info@riyadhaletqan.com" className="text-muted-foreground hover:text-primary">
                  info@riyadhaletqan.com
                </a>
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <a href="#" className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="#" className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="#" className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Linkedin className="h-4 w-4" />
              </a>
              <a href="#" className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Products */}
          <div>
            <h3 className="font-semibold mb-4">Products</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/products?category=drives" className="text-sm text-muted-foreground hover:text-primary">
                  Drives & Motors
                </Link>
              </li>
              <li>
                <Link href="/products?category=plc" className="text-sm text-muted-foreground hover:text-primary">
                  PLCs & Controllers
                </Link>
              </li>
              <li>
                <Link href="/products?category=sensors" className="text-sm text-muted-foreground hover:text-primary">
                  Sensors
                </Link>
              </li>
              <li>
                <Link href="/products?category=safety" className="text-sm text-muted-foreground hover:text-primary">
                  Safety Systems
                </Link>
              </li>
              <li>
                <Link href="/products?category=power" className="text-sm text-muted-foreground hover:text-primary">
                  Power Distribution
                </Link>
              </li>
            </ul>
          </div>

          {/* Services & Company */}
          <div>
            <h3 className="font-semibold mb-4">Services</h3>
            <ul className="space-y-2 mb-6">
              <li>
                <Link href="/services/amc" className="text-sm text-muted-foreground hover:text-primary">
                  Annual Maintenance Contracts
                </Link>
              </li>
              <li>
                <Link href="/services/installation" className="text-sm text-muted-foreground hover:text-primary">
                  Installation Services
                </Link>
              </li>
              <li>
                <Link href="/services/calibration" className="text-sm text-muted-foreground hover:text-primary">
                  Calibration & Verification
                </Link>
              </li>
              <li>
                <Link href="/services/commissioning" className="text-sm text-muted-foreground hover:text-primary">
                  Testing & Commissioning
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/shipping" className="text-sm text-muted-foreground hover:text-primary">
                  Shipping & Delivery
                </Link>
              </li>
              <li>
                <Link href="/returns" className="text-sm text-muted-foreground hover:text-primary">
                  Returns & Refunds
                </Link>
              </li>
              <li>
                <Link href="/payments" className="text-sm text-muted-foreground hover:text-primary">
                  Secure Payments
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-sm text-muted-foreground hover:text-primary">
                  Terms & Conditions
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>© {new Date().getFullYear()} Riyadh Aletqan Company. All rights reserved.</p>
            <div className="flex gap-6">
              <span>Trusted by 500+ companies across GCC</span>
              <span>•</span>
              <span>ISO 9001:2015 Certified</span>
            </div>
          </div>
        </div>
      </div>
    </footer>);

}