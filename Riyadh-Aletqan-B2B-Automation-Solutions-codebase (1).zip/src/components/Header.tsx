"use client";

import { useState } from "react";
import Link from "next/link";
import { Search, ShoppingCart, Menu, X, Globe, Phone, Mail, ChevronDown, Factory, Store, Shield, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useSession } from "@/lib/auth-client";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [language, setLanguage] = useState<"en" | "ar">("en");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCategoryMenu, setShowCategoryMenu] = useState(false);
  const [hoveredCategory, setHoveredCategory] = useState<string>("Drives");
  const { data: session } = useSession();

  const categories = [
    {
      name: "DRIVES & MOTORS",
      value: "Drives",
      subcategories: [
        "Variable Frequency Drives",
        "Servo Drives",
        "DC Drives",
        "Soft Starters",
        "Motor Starters",
        "Motor Protection"
      ]
    },
    {
      name: "PLCs & CONTROLLERS",
      value: "PLCs",
      subcategories: [
        "Programmable Logic Controllers",
        "PAC Systems",
        "Remote I/O",
        "Expansion Modules",
        "Control Panels",
        "Industrial PCs"
      ]
    },
    {
      name: "SENSORS",
      value: "Sensors",
      subcategories: [
        "Proximity Sensors",
        "Photoelectric Sensors",
        "Ultrasonic Sensors",
        "Pressure Sensors",
        "Temperature Sensors",
        "Flow Sensors"
      ]
    },
    {
      name: "SAFETY SYSTEMS",
      value: "Safety",
      subcategories: [
        "Safety Relays",
        "Light Curtains",
        "Safety Switches",
        "Emergency Stop Devices",
        "Safety PLCs",
        "Safety Mats"
      ]
    },
    {
      name: "POWER DISTRIBUTION",
      value: "Power",
      subcategories: [
        "Circuit Breakers",
        "Contactors",
        "Overload Relays",
        "Distribution Panels",
        "Power Supplies",
        "Transformers"
      ]
    },
    {
      name: "HMI & SCADA",
      value: "HMI",
      subcategories: [
        "Touch Panels",
        "Operator Interfaces",
        "SCADA Software",
        "Industrial Monitors",
        "Panel PCs",
        "Remote Access"
      ]
    }
  ];

  // Category images mapping
  const categoryImages: Record<string, string> = {
    "Drives": "https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop",
    "PLCs": "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop",
    "Sensors": "https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=800&h=800&fit=crop",
    "Safety": "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=800&h=800&fit=crop",
    "Power": "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800&h=800&fit=crop",
    "HMI": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=800&fit=crop"
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-4">
              <a href="tel:+966123456789" className="flex items-center gap-2 hover:opacity-80">
                <Phone className="h-3.5 w-3.5" />
                <span>+966 12 345 6789</span>
              </a>
              <a href="mailto:info@riyadhenergy.com" className="hidden md:flex items-center gap-2 hover:opacity-80">
                <Mail className="h-3.5 w-3.5" />
                <span>info@riyadhenergy.com</span>
              </a>
              {/* 12-Month Warranty Badge - Top Bar */}
              <div className="hidden lg:flex items-center gap-1.5 bg-secondary text-secondary-foreground px-3 py-1 rounded-full ml-2">
                <Shield className="h-3.5 w-3.5" />
                <span className="font-semibold">12-Month Warranty</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {session?.user && (
                <Link 
                  href="/admin"
                  className="flex items-center gap-1.5 hover:opacity-80 bg-primary-foreground/10 px-3 py-1 rounded"
                >
                  <Shield className="h-3.5 w-3.5" />
                  <span>Admin</span>
                </Link>
              )}
              <Button
                variant="ghost"
                size="sm"
                className="h-7 text-primary-foreground hover:bg-primary-foreground/10"
                onClick={() => setLanguage(language === "en" ? "ar" : "en")}
              >
                <Globe className="h-4 w-4 mr-1" />
                {language === "en" ? "العربية" : "English"}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="text-primary-foreground px-3 py-3 rounded-lg flex items-center justify-center shadow-md !bg-[url(https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/cfd04db7-e90f-483e-af86-349ca392d761/visual-edit-uploads/1763628248863-jdejhahj47d.webp)] !bg-cover !bg-center">
              <Factory className="h-7 w-7 !bg-none !bg-cover !bg-center" strokeWidth={2.5} />
            </div>
            <div className="hidden md:block">
              <div className="font-bold text-lg leading-tight">Riyadh Energy</div>
              <div className="text-xs text-muted-foreground">Powered by Riyadh Aletqan</div>
            </div>
          </Link>

          {/* 12-Month Warranty Badge - Mobile & Tablet */}
          <div className="flex lg:hidden items-center gap-1.5 bg-secondary text-secondary-foreground px-2.5 py-1.5 rounded-full">
            <Shield className="h-3.5 w-3.5" />
            <span className="text-xs font-semibold">12-Month Warranty</span>
          </div>

          {/* Search Bar */}
          <div className="hidden lg:flex flex-1 max-w-xl">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search by product, code, or brand..."
                className="pl-10 pr-4"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-secondary text-secondary-foreground text-xs flex items-center justify-center">
                0
              </span>
            </Button>

            {/* Mobile Menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon">
                  {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <nav className="flex flex-col gap-4 mt-8">
                  {session?.user && (
                    <Link
                      href="/admin"
                      className="flex items-center gap-2 text-lg font-medium text-primary"
                      onClick={() => setIsOpen(false)}
                    >
                      <Shield className="h-5 w-5" />
                      {language === "en" ? "Admin Dashboard" : "لوحة الإدارة"}
                    </Link>
                  )}
                  
                  <Link
                    href="/"
                    className="text-lg font-medium hover:text-primary"
                    onClick={() => setIsOpen(false)}
                  >
                    {language === "en" ? "Home" : "الرئيسية"}
                  </Link>
                  
                  <div>
                    <Link
                      href="/products"
                      className="text-lg font-medium hover:text-primary"
                      onClick={() => setIsOpen(false)}
                    >
                      {language === "en" ? "Store" : "المتجر"}
                    </Link>
                    <div className="ml-4 mt-2 flex flex-col gap-2">
                      <Link
                        href="/products"
                        className="text-sm text-muted-foreground hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        {language === "en" ? "All Categories" : "جميع الفئات"}
                      </Link>
                      {categories.map((category) => (
                        <div key={category.value}>
                          <Link
                            href={`/products?category=${category.value.toLowerCase()}`}
                            className="text-sm font-medium text-foreground hover:text-primary"
                            onClick={() => setIsOpen(false)}
                          >
                            {category.name}
                          </Link>
                          <div className="ml-3 mt-1 flex flex-col gap-1">
                            {category.subcategories.map((sub) => (
                              <Link
                                key={sub}
                                href={`/products?category=${category.value.toLowerCase()}`}
                                className="text-xs text-muted-foreground hover:text-primary"
                                onClick={() => setIsOpen(false)}
                              >
                                {sub}
                              </Link>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <Link
                      href="/services"
                      className="text-lg font-medium hover:text-primary"
                      onClick={() => setIsOpen(false)}
                    >
                      {language === "en" ? "Services" : "الخدمات"}
                    </Link>
                    <div className="ml-4 mt-2 flex flex-col gap-2">
                      <Link
                        href="/services/amc"
                        className="text-sm text-muted-foreground hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        {language === "en" ? "AMC" : "عقود الصيانة"}
                      </Link>
                      <Link
                        href="/services/installation"
                        className="text-sm text-muted-foreground hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        {language === "en" ? "Installation" : "التركيب"}
                      </Link>
                      <Link
                        href="/services/calibration"
                        className="text-sm text-muted-foreground hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        {language === "en" ? "Calibration" : "المعايرة"}
                      </Link>
                      <Link
                        href="/services/commissioning"
                        className="text-sm text-muted-foreground hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        {language === "en" ? "Testing & Commissioning" : "الاختبار والتشغيل"}
                      </Link>
                    </div>
                  </div>
                  
                  <Link
                    href="/turnkey-projects"
                    className="text-lg font-medium hover:text-primary"
                    onClick={() => setIsOpen(false)}
                  >
                    {language === "en" ? "Turnkey Projects" : "المشاريع المتكاملة"}
                  </Link>
                  
                  <Link
                    href="/request-quote"
                    className="text-lg font-medium hover:text-primary"
                    onClick={() => setIsOpen(false)}
                  >
                    {language === "en" ? "Request Quote" : "طلب عرض سعر"}
                  </Link>
                  
                  <Link
                    href="/partner"
                    className="text-lg font-medium hover:text-primary"
                    onClick={() => setIsOpen(false)}
                  >
                    {language === "en" ? "Become a Partner" : "كن شريكاً"}
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="lg:hidden mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Desktop Navigation */}
      <div className="hidden lg:block border-t">
        <div className="container mx-auto px-4">
          <nav className="flex items-center justify-center gap-6 py-3">
            <Link
              href="/"
              className="text-sm font-medium hover:text-primary"
            >
              {language === "en" ? "Home" : "الرئيسية"}
            </Link>
            
            {/* Visual Category Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setShowCategoryMenu(true)}
              onMouseLeave={() => setShowCategoryMenu(false)}
            >
              <Link
                href="/products"
                className="flex items-center gap-1 font-medium hover:text-primary transition-colors text-lg text-primary font-bold px-4 py-1.5 bg-primary/10 rounded-md"
              >
                <Store className="h-5 w-5 mr-1" />
                {language === "en" ? "Store" : "المتجر"}
                <ChevronDown className="h-4 w-4" />
              </Link>

              {/* Visual Dropdown Menu */}
              {showCategoryMenu && (
                <div className="absolute left-0 top-full mt-2 w-[900px] bg-background border rounded-lg shadow-xl z-50">
                  <div className="grid grid-cols-12 min-h-[450px]">
                    {/* Categories List - Left Side */}
                    <div className="col-span-3 border-r bg-muted/30 rounded-l-lg">
                      <div className="p-2">
                        <Link
                          href="/products"
                          className="block w-full text-left px-4 py-3 mb-1 rounded-lg hover:bg-muted text-sm font-medium border-b"
                        >
                          All Categories
                        </Link>
                        {categories.map((category) => (
                          <button
                            key={category.value}
                            className={`w-full text-left px-4 py-3 rounded-lg transition-all font-semibold text-xs ${
                              hoveredCategory === category.value
                                ? "bg-primary text-primary-foreground shadow-sm"
                                : "hover:bg-muted"
                            }`}
                            onMouseEnter={() => setHoveredCategory(category.value)}
                          >
                            {category.name}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Subcategories - Middle Section */}
                    <div className="col-span-6 p-6">
                      <h3 className="text-lg font-bold mb-4 text-primary">
                        {categories.find(c => c.value === hoveredCategory)?.name}
                      </h3>
                      <div className="grid grid-cols-2 gap-2">
                        {categories
                          .find(c => c.value === hoveredCategory)
                          ?.subcategories.map((subcategory) => (
                            <Link
                              key={subcategory}
                              href={`/products?category=${hoveredCategory}`}
                              className="text-left px-3 py-2 rounded-md hover:bg-muted transition-colors group flex items-center justify-between"
                            >
                              <span className="text-xs font-medium group-hover:text-primary">
                                {subcategory}
                              </span>
                              <ChevronRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                            </Link>
                          ))}
                      </div>
                    </div>

                    {/* Product Image - Right Side */}
                    <div className="col-span-3 bg-muted/50 p-6 flex items-center justify-center rounded-r-lg">
                      <div className="relative w-full h-full flex items-center justify-center">
                        <img
                          src={categoryImages[hoveredCategory]}
                          alt={categories.find(c => c.value === hoveredCategory)?.name}
                          className="max-w-full max-h-[350px] object-contain rounded-lg shadow-lg transition-all duration-300"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            {/* Services Dropdown - keeping simple */}
            <div className="relative group">
              <button className="flex items-center gap-1 font-medium hover:text-primary transition-colors text-sm">
                {language === "en" ? "Services" : "الخدمات"}
                <ChevronDown className="h-4 w-4" />
              </button>
              <div className="absolute left-0 top-full mt-2 w-56 bg-background border rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                <div className="p-2">
                  <Link href="/services/amc" className="block px-4 py-2 rounded-md hover:bg-muted text-sm">
                    {language === "en" ? "AMC" : "عقود الصيانة"}
                  </Link>
                  <Link href="/services/installation" className="block px-4 py-2 rounded-md hover:bg-muted text-sm">
                    {language === "en" ? "Installation" : "التركيب"}
                  </Link>
                  <Link href="/services/calibration" className="block px-4 py-2 rounded-md hover:bg-muted text-sm">
                    {language === "en" ? "Calibration" : "المعايرة"}
                  </Link>
                  <Link href="/services/commissioning" className="block px-4 py-2 rounded-md hover:bg-muted text-sm">
                    {language === "en" ? "Testing & Commissioning" : "الاختبار والتشغيل"}
                  </Link>
                </div>
              </div>
            </div>
            
            <Link
              href="/turnkey-projects"
              className="text-sm font-medium hover:text-primary"
            >
              {language === "en" ? "Turnkey Projects" : "المشاريع المتكاملة"}
            </Link>
            
            <Link
              href="/request-quote"
              className="text-sm font-medium hover:text-primary"
            >
              {language === "en" ? "Request Quote" : "طلب عرض سعر"}
            </Link>
            
            <Link
              href="/partner"
              className="text-sm font-medium hover:text-primary"
            >
              {language === "en" ? "Become a Partner" : "كن شريكاً"}
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}