import { Html, Body, Container, Heading, Text, Section, Hr } from '@react-email/components';

interface QuoteAutoReplyProps {
  name: string;
  companyName: string;
  email: string;
}

export function QuoteAutoReplyTemplate({ name, companyName, email }: QuoteAutoReplyProps) {
  return (
    <Html>
      <Body style={{ fontFamily: 'Arial, sans-serif', backgroundColor: '#f4f4f4', padding: '20px' }}>
        <Container style={{ 
          maxWidth: '600px', 
          margin: '0 auto',
          backgroundColor: '#ffffff', 
          borderRadius: '8px',
          padding: '40px 30px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <Heading style={{ 
            color: '#1a1a2e', 
            fontSize: '24px', 
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            Thank You for Your Quote Request
          </Heading>
          
          <Section style={{ marginTop: '30px', marginBottom: '30px' }}>
            <Text style={{ fontSize: '16px', lineHeight: '24px', color: '#333333', marginBottom: '15px' }}>
              Dear {name},
            </Text>
            
            <Text style={{ fontSize: '16px', lineHeight: '24px', color: '#333333', marginBottom: '15px' }}>
              Thank you for submitting your quote request. Our team has received your information and will contact you within 24 hours.
            </Text>
            
            <Text style={{ fontSize: '16px', lineHeight: '24px', color: '#333333', marginBottom: '15px' }}>
              If you have additional details or documents, feel free to reply to this email.
            </Text>
            
            <Text style={{ fontSize: '16px', lineHeight: '24px', color: '#333333', marginBottom: '20px' }}>
              Thank you for choosing Riyadh Aletqan.
            </Text>
          </Section>

          <Hr style={{ borderColor: '#e0e0e0', margin: '30px 0' }} />

          <Section style={{ backgroundColor: '#f9f9f9', padding: '20px', borderRadius: '6px' }}>
            <Text style={{ fontSize: '14px', color: '#666666', marginBottom: '10px', fontWeight: 'bold' }}>
              Your Submission Details:
            </Text>
            <Text style={{ fontSize: '14px', color: '#666666', margin: '5px 0' }}>
              <strong>Company:</strong> {companyName}
            </Text>
            <Text style={{ fontSize: '14px', color: '#666666', margin: '5px 0' }}>
              <strong>Email:</strong> {email}
            </Text>
          </Section>

          <Section style={{ marginTop: '30px', textAlign: 'center' }}>
            <Text style={{ fontSize: '14px', color: '#999999', lineHeight: '20px' }}>
              Riyadh Aletqan - Industrial Automation & Electrical Solutions
              <br />
              Saudi Arabia & GCC Region
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}
