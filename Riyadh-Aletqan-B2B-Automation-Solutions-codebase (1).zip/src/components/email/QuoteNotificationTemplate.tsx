import { Html, Body, Container, Heading, Text, Section, Hr } from '@react-email/components';

interface QuoteNotificationProps {
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  country: string;
  city: string;
  industry: string;
  productDescription: string;
  quantity: string;
  deliveryTimeline: string;
  additionalRequirements: string;
  scheduledDate?: string;
  scheduledTime?: string;
  requestType?: string;
}

export function QuoteNotificationTemplate(props: QuoteNotificationProps) {
  const {
    companyName,
    contactPerson,
    email,
    phone,
    country,
    city,
    industry,
    productDescription,
    quantity,
    deliveryTimeline,
    additionalRequirements,
    scheduledDate,
    scheduledTime,
    requestType
  } = props;

  return (
    <Html>
      <Body style={{ fontFamily: 'Arial, sans-serif', backgroundColor: '#f4f4f4', padding: '20px' }}>
        <Container style={{ 
          maxWidth: '700px', 
          margin: '0 auto',
          backgroundColor: '#ffffff', 
          borderRadius: '8px',
          padding: '40px 30px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <Heading style={{ 
            color: '#1a1a2e', 
            fontSize: '26px', 
            marginBottom: '10px',
            textAlign: 'center'
          }}>
            New Quote Request Submission
          </Heading>
          
          <Text style={{ 
            textAlign: 'center', 
            color: '#666666', 
            fontSize: '14px',
            marginBottom: '30px'
          }}>
            {requestType === 'meeting' ? 'Meeting Request' : requestType === 'site-visit' ? 'Site Visit Request' : 'Quote Request'}
          </Text>

          <Hr style={{ borderColor: '#e0e0e0', margin: '20px 0' }} />

          {/* Scheduled Date/Time Section (if applicable) */}
          {scheduledDate && (
            <>
              <Section style={{ marginBottom: '30px', backgroundColor: '#fff3cd', padding: '15px', borderRadius: '6px', borderLeft: '4px solid #f0ad4e' }}>
                <Text style={{ fontSize: '16px', color: '#856404', fontWeight: 'bold', marginBottom: '10px' }}>
                  📅 Scheduled Appointment
                </Text>
                <Text style={{ fontSize: '15px', color: '#856404', margin: '5px 0' }}>
                  <strong>Date:</strong> {scheduledDate}
                </Text>
                {scheduledTime && (
                  <Text style={{ fontSize: '15px', color: '#856404', margin: '5px 0' }}>
                    <strong>Time:</strong> {scheduledTime}
                  </Text>
                )}
              </Section>
            </>
          )}

          {/* Company Information */}
          <Section style={{ marginBottom: '25px' }}>
            <Heading as="h2" style={{ fontSize: '18px', color: '#1a1a2e', marginBottom: '15px', borderBottom: '2px solid #1a1a2e', paddingBottom: '8px' }}>
              Company Information
            </Heading>
            <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
              <strong>Company Name:</strong> {companyName}
            </Text>
            <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
              <strong>Contact Person:</strong> {contactPerson}
            </Text>
            <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
              <strong>Email:</strong> <a href={`mailto:${email}`} style={{ color: '#0066cc' }}>{email}</a>
            </Text>
            <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
              <strong>Phone:</strong> <a href={`tel:${phone}`} style={{ color: '#0066cc' }}>{phone}</a>
            </Text>
            <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
              <strong>Location:</strong> {city}, {country}
            </Text>
            {industry && (
              <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
                <strong>Industry:</strong> {industry}
              </Text>
            )}
          </Section>

          <Hr style={{ borderColor: '#e0e0e0', margin: '20px 0' }} />

          {/* Product/Service Requirements */}
          <Section style={{ marginBottom: '25px' }}>
            <Heading as="h2" style={{ fontSize: '18px', color: '#1a1a2e', marginBottom: '15px', borderBottom: '2px solid #1a1a2e', paddingBottom: '8px' }}>
              Requirements
            </Heading>
            <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
              <strong>Description:</strong>
            </Text>
            <Text style={{ 
              fontSize: '15px', 
              color: '#333333', 
              backgroundColor: '#f9f9f9', 
              padding: '12px', 
              borderRadius: '4px',
              whiteSpace: 'pre-wrap',
              marginTop: '8px'
            }}>
              {productDescription}
            </Text>
            {quantity && (
              <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0', marginTop: '15px' }}>
                <strong>Quantity:</strong> {quantity}
              </Text>
            )}
            {deliveryTimeline && (
              <Text style={{ fontSize: '15px', color: '#333333', margin: '8px 0' }}>
                <strong>Delivery Timeline:</strong> {deliveryTimeline}
              </Text>
            )}
          </Section>

          {additionalRequirements && (
            <>
              <Hr style={{ borderColor: '#e0e0e0', margin: '20px 0' }} />
              <Section style={{ marginBottom: '25px' }}>
                <Heading as="h2" style={{ fontSize: '18px', color: '#1a1a2e', marginBottom: '15px', borderBottom: '2px solid #1a1a2e', paddingBottom: '8px' }}>
                  Additional Requirements
                </Heading>
                <Text style={{ 
                  fontSize: '15px', 
                  color: '#333333', 
                  backgroundColor: '#f9f9f9', 
                  padding: '12px', 
                  borderRadius: '4px',
                  whiteSpace: 'pre-wrap'
                }}>
                  {additionalRequirements}
                </Text>
              </Section>
            </>
          )}

          <Hr style={{ borderColor: '#e0e0e0', margin: '20px 0' }} />

          <Section style={{ textAlign: 'center', padding: '20px', backgroundColor: '#f0f8ff', borderRadius: '6px' }}>
            <Text style={{ fontSize: '14px', color: '#666666', marginBottom: '10px' }}>
              Please respond to this quote request within 24 hours
            </Text>
            <Text style={{ fontSize: '13px', color: '#999999' }}>
              Riyadh Aletqan - Quote Management System
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  );
}
