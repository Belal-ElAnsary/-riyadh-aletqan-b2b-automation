import { db } from '@/db';
import { products } from '@/db/schema';

async function main() {
    const sampleProducts = [
        {
            name: 'Siemens SINAMICS G120C',
            code: '6SL3210-1KE21-3UB2',
            category: 'Drives',
            brand: 'Siemens',
            price: 1250,
            image: 'https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop',
            description: 'Compact frequency inverter for variable speed drive applications with integrated safety features',
            inStock: true,
            stockCount: 12,
            priceType: 'fixed',
            specifications: {
                'Power Rating': '7.5 kW',
                'Voltage': '380-480V AC',
                'Current': '18A',
                'Frequency': '0-550 Hz',
                'Protection Class': 'IP20',
                'Weight': '2.8 kg',
                'Dimensions': '185 x 275 x 195 mm',
                'Cooling': 'Natural convection'
            },
            features: [
                'Easy commissioning with BOP-2',
                'Integrated STO safety',
                'USS, Modbus RTU protocols',
                'Energy saving eco mode',
                '150% overload for 60s'
            ],
            warranty: '24 months',
            datasheet: null,
            leadTime: '2-3 business days',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Schneider Electric Altivar ATV320',
            code: 'ATV320U75N4B',
            category: 'Drives',
            brand: 'Schneider Electric',
            price: 980,
            image: 'https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop',
            description: 'Compact variable speed drive with advanced motor control for industrial applications',
            inStock: true,
            stockCount: 8,
            priceType: 'fixed',
            specifications: {
                'Power Rating': '7.5 kW',
                'Voltage': '380-500V AC',
                'Current': '16.7A',
                'Frequency': '0-500 Hz',
                'Protection Class': 'IP20',
                'Weight': '2.5 kg',
                'Dimensions': '180 x 268 x 195 mm'
            },
            features: [
                'Compact design',
                'Built-in Modbus and CANopen',
                'Integrated EMC filter',
                'Auto-tuning',
                'Energy savings up to 30%'
            ],
            warranty: '18 months',
            datasheet: null,
            leadTime: '1-2 business days',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Siemens SIMATIC S7-1200',
            code: '6ES7214-1AG40-0XB0',
            category: 'PLCs',
            brand: 'Siemens',
            price: 2450,
            image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop',
            description: 'Compact PLC for discrete and continuous control with integrated communication',
            inStock: true,
            stockCount: 5,
            priceType: 'fixed',
            specifications: {
                'CPU': 'CPU 1214C DC/DC/DC',
                'Memory': '50 KB work memory',
                'Digital Inputs': '14',
                'Digital Outputs': '10',
                'Analog Inputs': '2',
                'Protection Class': 'IP20',
                'Operating Voltage': '24V DC'
            },
            features: [
                'Integrated Ethernet/PROFINET',
                'Modular expansion',
                'Integrated technology functions',
                'High-speed counters',
                'TIA Portal programming'
            ],
            warranty: '36 months',
            datasheet: null,
            leadTime: '3-5 business days',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'ABB PLC PM554-TP',
            code: '1SAP120600R0071',
            category: 'PLCs',
            brand: 'ABB',
            price: 3200,
            image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop',
            description: 'Advanced PLC with integrated touchscreen HMI for complex automation tasks',
            inStock: false,
            stockCount: 0,
            priceType: 'quote',
            specifications: {
                'CPU': 'PM554 with touchscreen',
                'Memory': '256 KB program, 512 KB data',
                'Display': '5.7" TFT color',
                'Digital I/O': 'Expandable',
                'Communication': 'Ethernet, RS-485',
                'Protection Class': 'IP65 front'
            },
            features: [
                'Integrated HMI',
                'IEC 61131-3 programming',
                'Web server',
                'Multiple protocols',
                'Rugged design'
            ],
            warranty: '24 months',
            datasheet: null,
            leadTime: '4-6 weeks (contact for availability)',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Omron E3Z Photoelectric Sensor',
            code: 'E3Z-D87',
            category: 'Sensors',
            brand: 'Omron',
            price: 145,
            image: 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?w=800&h=800&fit=crop',
            description: 'Long-range photoelectric sensor with high immunity to ambient light',
            inStock: true,
            stockCount: 45,
            priceType: 'fixed',
            specifications: {
                'Detection Range': '30m (reflective)',
                'Light Source': 'Red LED',
                'Response Time': '1ms',
                'Output': 'NPN/PNP selectable',
                'Protection Class': 'IP67',
                'Operating Voltage': '12-24V DC',
                'Cable Length': '2m'
            },
            features: [
                'Long sensing range up to 30m',
                'High immunity to ambient light',
                'Easy optical axis alignment',
                'Robust metal housing',
                'Temperature compensation'
            ],
            warranty: '12 months',
            datasheet: null,
            leadTime: 'Same day dispatch',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Schneider Safety Relay',
            code: 'XPSAK311144P',
            category: 'Safety',
            brand: 'Schneider Electric',
            price: 850,
            image: 'https://images.unsplash.com/photo-1581092162384-8987c1d64718?w=800&h=800&fit=crop',
            description: 'Modular safety relay for monitoring emergency stop circuits and safety devices',
            inStock: true,
            stockCount: 15,
            priceType: 'fixed',
            specifications: {
                'Safety Category': 'Category 4',
                'Contacts': '4 NO + 2 NC',
                'Voltage': '24V DC',
                'Response Time': '<20ms',
                'Protection Class': 'IP20'
            },
            features: [
                'Modular safety relay',
                'Emergency stop monitoring',
                'Two-hand control',
                'Light curtain interface',
                'LED diagnostics'
            ],
            warranty: '24 months',
            datasheet: null,
            leadTime: '1-2 business days',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'ABB Circuit Breaker',
            code: 'S804PV-S125',
            category: 'Power',
            brand: 'ABB',
            price: 420,
            image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800&h=800&fit=crop',
            description: 'DC optimized circuit breaker for solar and industrial power applications',
            inStock: true,
            stockCount: 28,
            priceType: 'fixed',
            specifications: {
                'Poles': '4',
                'Current Rating': '125A',
                'Breaking Capacity': '25 kA',
                'Voltage': '690V AC',
                'Type': 'DC optimized'
            },
            features: [
                'Optimized for solar applications',
                'Wide voltage range',
                'Trip-free mechanism',
                'Auxiliary contacts available',
                'DIN rail mounting'
            ],
            warranty: '12 months',
            datasheet: null,
            leadTime: 'Same day dispatch',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Siemens SIMATIC HMI TP700',
            code: '6AV2124-0GC01-0AX0',
            category: 'HMI',
            brand: 'Siemens',
            price: 1680,
            image: 'https://images.unsplash.com/photo-1581092226825-a6a2a5aee158?w=800&h=800&fit=crop',
            description: '7-inch widescreen touch panel with PROFINET connectivity for machine visualization',
            inStock: true,
            stockCount: 7,
            priceType: 'fixed',
            specifications: {
                'Display': '7" TFT widescreen',
                'Resolution': '800x480 pixels',
                'Memory': '4 MB user memory',
                'Communication': 'PROFINET, Ethernet',
                'Protection Class': 'IP65 front',
                'Touch': 'Analog resistive'
            },
            features: [
                'Widescreen display',
                'Multi-language support',
                'Recipe management',
                'Alarm system',
                'Integrated web server'
            ],
            warranty: '24 months',
            datasheet: null,
            leadTime: '2-3 business days',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Rockwell PowerFlex 525',
            code: '25B-D6P0N104',
            category: 'Drives',
            brand: 'Rockwell Automation',
            price: 1890,
            image: 'https://images.unsplash.com/photo-1581092918484-8313e1f7e8d4?w=800&h=800&fit=crop',
            description: 'Compact AC drive with EtherNet/IP connectivity for flexible motor control',
            inStock: true,
            stockCount: 10,
            priceType: 'fixed',
            specifications: {
                'Power Rating': '6 kW',
                'Voltage': '480V AC',
                'Current': '14.8A',
                'Communication': 'EtherNet/IP',
                'Protection Class': 'IP20',
                'Cooling': 'Fan'
            },
            features: [
                'Compact footprint',
                'EtherNet/IP built-in',
                'Safe Torque-Off',
                'USB port for setup',
                'Energy monitoring'
            ],
            warranty: '18 months',
            datasheet: null,
            leadTime: '2-4 business days',
            createdAt: new Date(),
            updatedAt: new Date()
        },
        {
            name: 'Mitsubishi iQ-F PLC',
            code: 'FX5U-32MT/ESS',
            category: 'PLCs',
            brand: 'Mitsubishi Electric',
            price: 2890,
            image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop',
            description: 'High-performance compact PLC with built-in positioning and Ethernet connectivity',
            inStock: false,
            stockCount: 0,
            priceType: 'quote',
            specifications: {
                'CPU': 'FX5U series',
                'I/O Points': '32 (16 in/16 out)',
                'Memory': '256 KB',
                'Communication': 'Ethernet, RS-485',
                'Programming': 'GX Works3'
            },
            features: [
                'High-speed processing',
                'Built-in positioning',
                'CC-Link IE Field support',
                'SD card slot',
                'Compact design'
            ],
            warranty: '24 months',
            datasheet: null,
            leadTime: '4-6 weeks',
            createdAt: new Date(),
            updatedAt: new Date()
        }
    ];

    await db.insert(products).values(sampleProducts);
    
    console.log('✅ Products seeder completed successfully');
}

main().catch((error) => {
    console.error('❌ Seeder failed:', error);
});